import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page";
import { Pill } from "@/components/badges";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidate, useTasks, useVehicles } from "@/lib/data";
import { addDaysISO, fmtDate, isOpen, todayISO } from "@/lib/task-utils";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/vehicles")({
  head: () => ({ meta: [{ title: "Vehicles — MS Transport To-Do" }, { name: "description", content: "Fleet documents and open tasks per vehicle." }, { property: "og:title", content: "Vehicles" }, { property: "og:description", content: "Fleet list." }] }),
  component: Vehicles,
});

function Doc({ d }: { d: string | null }) {
  if (!d) return <span className="text-muted-foreground">—</span>;
  const tone = d < todayISO() ? "solidDanger" : d <= addDaysISO(todayISO(), 30) ? "warning" : "neutral";
  return <Pill tone={tone}>{fmtDate(d)}</Pill>;
}

function Vehicles() {
  const { isOwner } = useSession();
  const { data: vehicles = [] } = useVehicles();
  const { data: tasks = [] } = useTasks();
  const invalidate = useInvalidate();
  const [f, setF] = useState({ vehicle_no: "", vehicle_type: "", insurance_expiry: "", fitness_expiry: "", pollution_expiry: "", permit_expiry: "" });
  const add = async (): Promise<void> => {
    if (!f.vehicle_no.trim()) { toast.error("Vehicle number required"); return; }
    const row = Object.fromEntries(Object.entries(f).map(([k, v]) => [k, v || null])) as typeof f;
    const { error } = await supabase.from("vehicles").insert({ ...row, vehicle_no: f.vehicle_no.trim().toUpperCase() });
    if (error) { toast.error(error.message); return; }
    toast.success("Vehicle added"); setF({ vehicle_no: "", vehicle_type: "", insurance_expiry: "", fitness_expiry: "", pollution_expiry: "", permit_expiry: "" }); invalidate("vehicles");
  };
  return (
    <>
      <PageHeader title="Vehicles" subtitle="Red = expired, amber = expiring within 30 days." />
      {isOwner && (
        <div className="card-surface mb-4 grid gap-2 p-4 md:grid-cols-7">
          <Input placeholder="Vehicle no." value={f.vehicle_no} onChange={(e) => setF({ ...f, vehicle_no: e.target.value })} />
          <Input placeholder="Type" value={f.vehicle_type} onChange={(e) => setF({ ...f, vehicle_type: e.target.value })} />
          {(["insurance_expiry", "fitness_expiry", "pollution_expiry", "permit_expiry"] as const).map((k) => (
            <Input key={k} type="date" title={k} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
          ))}
          <Button onClick={add}>Add vehicle</Button>
        </div>
      )}
      <div className="card-surface overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr><th className="px-4 py-2">Vehicle</th><th className="px-3 py-2">Type</th><th className="px-3 py-2">Insurance</th><th className="px-3 py-2">Fitness</th><th className="px-3 py-2">Pollution</th><th className="px-3 py-2">Permit</th><th className="px-3 py-2">Open tasks</th></tr>
          </thead>
          <tbody>
            {vehicles.map((v) => (
              <tr key={v.id} className="border-t">
                <td className="px-4 py-2 font-mono font-semibold"><Link to="/search" search={{ q: v.vehicle_no }} className="text-primary hover:underline">{v.vehicle_no}</Link></td>
                <td className="px-3 py-2">{v.vehicle_type}</td>
                <td className="px-3 py-2"><Doc d={v.insurance_expiry} /></td><td className="px-3 py-2"><Doc d={v.fitness_expiry} /></td>
                <td className="px-3 py-2"><Doc d={v.pollution_expiry} /></td><td className="px-3 py-2"><Doc d={v.permit_expiry} /></td>
                <td className="px-3 py-2 font-mono">{tasks.filter((t) => isOpen(t) && t.vehicle_no === v.vehicle_no).length}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
