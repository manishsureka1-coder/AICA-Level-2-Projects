import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertOwner(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "owner" });
  if (!data) throw new Error("Only the owner can do this");
}

export const createStaffLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({
    employeeId: z.string().uuid(),
    email: z.string().trim().email().max(255),
    password: z.string().min(8).max(72),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertOwner(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: emp } = await supabaseAdmin.from("employees").select("id,user_id,name").eq("id", data.employeeId).single();
    if (!emp) throw new Error("Employee not found");
    if (emp.user_id) throw new Error("This employee already has a login");
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email, password: data.password, email_confirm: true, user_metadata: { name: emp.name },
    });
    if (error || !created.user) throw new Error(error?.message ?? "Could not create login");
    await supabaseAdmin.from("employees").update({ user_id: created.user.id, email: data.email }).eq("id", emp.id);
    await supabaseAdmin.from("user_roles").insert({ user_id: created.user.id, role: "staff" });
    await supabaseAdmin.from("audit_log").insert({ action: "Login created", details: `Login created for ${emp.name} (${data.email})`, changed_by: "Owner" });
    return { ok: true };
  });

export const resetStaffPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ employeeId: z.string().uuid(), password: z.string().min(8).max(72) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertOwner(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: emp } = await supabaseAdmin.from("employees").select("user_id,name").eq("id", data.employeeId).single();
    if (!emp?.user_id) throw new Error("This employee has no login yet");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(emp.user_id, { password: data.password });
    if (error) throw new Error(error.message);
    await supabaseAdmin.from("audit_log").insert({ action: "Password reset", details: `Password reset for ${emp.name}`, changed_by: "Owner" });
    return { ok: true };
  });

export const setStaffActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ employeeId: z.string().uuid(), active: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertOwner(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: emp } = await supabaseAdmin.from("employees").select("user_id,name,is_owner").eq("id", data.employeeId).single();
    if (!emp) throw new Error("Employee not found");
    if (emp.is_owner) throw new Error("The owner cannot be disabled");
    await supabaseAdmin.from("employees").update({ active: data.active }).eq("id", data.employeeId);
    if (emp.user_id) {
      await supabaseAdmin.auth.admin.updateUserById(emp.user_id, { ban_duration: data.active ? "none" : "876000h" });
    }
    await supabaseAdmin.from("audit_log").insert({ action: data.active ? "User enabled" : "User disabled", details: emp.name, changed_by: "Owner" });
    return { ok: true };
  });
