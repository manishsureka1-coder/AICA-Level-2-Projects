@echo off
title MS Transport To-Do - Office Server
cd /d "%~dp0"

where bun >nul 2>nul
if errorlevel 1 (
  echo Bun is not installed. Installing now...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm bun.sh/install.ps1 | iex"
  set "PATH=%USERPROFILE%\.bun\bin;%PATH%"
)

if not exist node_modules (
  echo Installing app files - first run only...
  call bun install
)

echo.
echo ==============================================
echo  MS Transport To-Do is starting...
echo  Staff on office WiFi open:  http://YOUR-PC-IP:8080
echo  Your PC IP address(es):
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do echo     http://%%a:8080
echo  Keep this window open. Close it to stop the app.
echo ==============================================
echo.

call bun run dev -- --host 0.0.0.0 --port 8080
pause
