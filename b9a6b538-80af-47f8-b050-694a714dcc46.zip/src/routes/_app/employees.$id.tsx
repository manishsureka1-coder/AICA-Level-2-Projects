import { createFileRoute } from "@tanstack/react-router";
import { OwnerOnly } from "@/components/page";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";
import { EmployeeBoard } from "./my-tasks";

export const Route = createFileRoute("/_app/employees/$id")({
  head: () => ({ meta: [{ title: "Employee Dashboard — MS Transport To-Do" }, { name: "description", content: "Employee task dashboard." }, { property: "og:title", content: "Employee Dashboard" }, { property: "og:description", content: "Employee task dashboard." }] }),
  component: EmpPage,
});

function EmpPage() {
  const { id } = Route.useParams();
  const { isOwner } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  if (!isOwner) return <OwnerOnly />;
  const e = emps.find((x) => x.id === id);
  return <EmployeeBoard title={e?.name ?? "Employee"} subtitle={`${e?.designation ?? ""} · ${e?.department ?? ""}`} tasks={tasks.filter((t) => t.assigned_to === id)} names={employeeMap(emps)} />;
}
