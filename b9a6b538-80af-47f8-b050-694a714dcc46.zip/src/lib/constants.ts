export const CATEGORIES = [
  "Vehicle Placement", "Loading", "Unloading", "Driver", "POD", "LR", "Billing",
  "Payment Collection", "Customer Follow-up", "Supplier Follow-up", "Diesel", "FASTag",
  "Vehicle Maintenance", "Tyre", "Insurance", "Permit", "Fitness", "Pollution",
  "Accident / Claim", "Accounts", "GST", "TDS", "Banking", "Tender", "EMD",
  "Bank Guarantee", "Purchase Order", "Compliance", "Other",
] as const;

export const PRIORITIES = ["Low", "Normal", "High", "Urgent", "Critical"] as const;

export const STATUSES = [
  "Not Started", "In Progress", "Waiting", "Waiting for Customer", "Waiting for Driver",
  "Waiting for Vehicle", "Waiting for Documents", "Waiting for Payment", "Completed", "Cancelled",
] as const;

export const RECURRENCES = ["None", "Daily", "Weekly", "Monthly", "Quarterly"] as const;

export const CLOSED = ["Completed", "Cancelled"];
