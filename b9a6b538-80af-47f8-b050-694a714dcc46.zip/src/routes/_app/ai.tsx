import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, AlertTriangle, Info, Siren } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";
import { ruleInsights } from "@/lib/insights";
import { aiManagementSummary } from "@/lib/ai.functions";
import { daysPending, isOpen, isOverdue, noUpdateDays } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/ai")({
  head: () => ({ meta: [{ title: "AI Management Assistant — MS Transport To-Do" }, { name: "description", content: "Rule-based and AI-generated management observations." }, { property: "og:title", content: "AI Assistant" }, { property: "og:description", content: "AI management assistant." }] }),
  component: AI,
});

function AI() {
  const { isOwner } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  const ask = useServerFn(aiManagementSummary);
  const [q, setQ] = useState("");
  const [out, setOut] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (!isOwner) return <OwnerOnly />;
  const insights = ruleInsights(tasks, emps);
  const names = employeeMap(emps);

  const run = async () => {
    setBusy(true); setErr(""); setOut("");
    const facts = JSON.stringify(tasks.filter(isOpen).map((t) => ({
      id: t.task_code, title: t.title, to: names[t.assigned_to ?? ""], cat: t.category, pri: t.priority, status: t.status,
      due: t.due_date, overdue: isOverdue(t), pendingDays: daysPending(t), daysSinceUpdate: noUpdateDays(t),
      vehicle: t.vehicle_no, customer: t.customer_name, ref: t.reference_no,
    })));
    try {
      const r = await ask({ data: { facts, question: q || undefined } });
      if (r.error) setErr(r.error); else setOut(r.text);
    } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  const Icon = { critical: Siren, warning: AlertTriangle, info: Info };
  const cls = { critical: "border-destructive bg-destructive/10 text-destructive", warning: "border-warning bg-warning/15", info: "border-border bg-card" };

  return (
    <>
      <PageHeader title="AI Management Assistant" subtitle="Rule-based observations always work. AI analysis adds a written briefing on demand." />
      <h2 className="mb-3 text-xl font-bold uppercase">Rule-based observations</h2>
      <div className="mb-8 grid gap-2 md:grid-cols-2">
        {insights.map((i, k) => {
          const I = Icon[i.level];
          return <div key={k} className={`flex gap-3 rounded-md border p-3 text-sm ${cls[i.level]}`}><I className="mt-0.5 h-4 w-4 shrink-0" /><span className="text-foreground">{i.text}</span></div>;
        })}
      </div>
      <h2 className="mb-3 text-xl font-bold uppercase">AI briefing</h2>
      <div className="card-surface space-y-3 p-5">
        <div className="flex gap-2">
          <Input placeholder="Optional question — e.g. Which customer follow-ups are most at risk?" value={q} onChange={(e) => setQ(e.target.value)} maxLength={1000} />
          <Button onClick={run} disabled={busy} className="bg-accent text-accent-foreground hover:bg-accent/90"><Sparkles className="mr-1 h-4 w-4" />{busy ? "Analysing…" : "Generate"}</Button>
        </div>
        {err && <p className="text-sm text-destructive">{err}</p>}
        {out && <div className="whitespace-pre-wrap rounded-md bg-muted p-4 text-sm leading-relaxed">{out}</div>}
      </div>
    </>
  );
}
