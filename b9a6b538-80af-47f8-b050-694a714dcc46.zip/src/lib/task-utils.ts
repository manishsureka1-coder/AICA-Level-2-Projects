import type { Tables } from "@/integrations/supabase/types";
import { CLOSED } from "./constants";

export type Task = Tables<"tasks">;
export type Employee = Tables<"employees">;

export const todayISO = () => {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
};
export const addDaysISO = (iso: string, n: number) => {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + n);
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
};
const dayDiff = (a: string, b: string) =>
  Math.round((new Date(b + "T00:00:00").getTime() - new Date(a + "T00:00:00").getTime()) / 86400000);

export const isOpen = (t: Task) => !CLOSED.includes(t.status);
export const isOverdue = (t: Task) => isOpen(t) && !!t.due_date && t.due_date < todayISO();
export const isDueToday = (t: Task) => isOpen(t) && t.due_date === todayISO();
export const isDueTomorrow = (t: Task) => isOpen(t) && t.due_date === addDaysISO(todayISO(), 1);
export const daysPending = (t: Task) => dayDiff(t.assigned_date, todayISO()) + 1;
export const daysOverdue = (t: Task) => (t.due_date ? dayDiff(t.due_date, todayISO()) : 0);
export const isCarriedForward = (t: Task) => isOpen(t) && t.assigned_date < todayISO();
export const noUpdateDays = (t: Task) =>
  Math.floor((Date.now() - new Date(t.last_update_at).getTime()) / 86400000);
export const isStale = (t: Task) => isOpen(t) && noUpdateDays(t) >= 2;
export const isCritical = (t: Task) => isOpen(t) && t.priority === "Critical";
export const isEscalated = (t: Task) =>
  isOverdue(t) && (t.priority === "Critical" || daysOverdue(t) > 2);
export const completedToday = (t: Task) =>
  t.status === "Completed" && !!t.completed_at && t.completed_at.slice(0, 10) === todayISO();

export const fmtDate = (iso?: string | null) => {
  if (!iso) return "—";
  const [y, m, d] = iso.slice(0, 10).split("-");
  return `${d}-${m}-${y}`;
};
export const fmtDateTime = (iso?: string | null) => {
  if (!iso) return "—";
  const d = new Date(iso);
  return `${fmtDate(iso)} ${d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}`;
};

export const searchText = (t: Task, assignee?: string) =>
  [t.task_code, t.title, t.description, t.vehicle_no, t.driver_name, t.customer_name,
    t.reference_no, t.loading_point, t.unloading_point, t.category, assignee]
    .filter(Boolean).join(" ").toLowerCase();

const PRI_RANK: Record<string, number> = { Critical: 5, Urgent: 4, High: 3, Normal: 2, Low: 1 };
export const attentionScore = (t: Task) =>
  (isEscalated(t) ? 100 : 0) + (isOverdue(t) ? 40 + daysOverdue(t) * 3 : 0) +
  (PRI_RANK[t.priority] ?? 0) * 8 + (isStale(t) ? 15 : 0) + (isDueToday(t) ? 10 : 0);
