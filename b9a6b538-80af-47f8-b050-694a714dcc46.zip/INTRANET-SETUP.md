# Run MS Transport To-Do on the office network

1. Download this project onto the office PC (GitHub or ZIP) and unzip it.
2. Make sure the `.env` file is in the folder (it connects to the online data).
3. Double-click `start-intranet.bat`. First run installs everything (needs internet).
4. When Windows Firewall asks, tick **Private networks** and click **Allow**.
5. The window shows addresses like `http://192.168.1.50:8080` — give that to staff.
6. Staff on the same WiFi open it in a browser and sign in with their login.

Tips: set the PC to never sleep; to auto-start, put a shortcut to
`start-intranet.bat` in `shell:startup` (Win+R, type `shell:startup`).
