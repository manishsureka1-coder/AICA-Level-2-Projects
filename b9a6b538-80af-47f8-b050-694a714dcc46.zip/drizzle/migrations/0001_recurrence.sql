CREATE OR REPLACE FUNCTION public.tasks_recur() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE nd date; step interval;
BEGIN
  IF NEW.status = 'Completed' AND OLD.status <> 'Completed' AND NEW.recurrence <> 'None' THEN
    step := CASE NEW.recurrence WHEN 'Daily' THEN interval '1 day' WHEN 'Weekly' THEN interval '7 days' WHEN 'Monthly' THEN interval '1 month' WHEN 'Quarterly' THEN interval '3 months' ELSE interval '1 day' END;
    nd := (coalesce(NEW.due_date, current_date) + step)::date;
    IF nd < current_date THEN nd := current_date; END IF;
    INSERT INTO tasks(title, description, assigned_to, category, priority, status, assigned_date, due_date, due_time, vehicle_no, driver_name, customer_name, loading_point, unloading_point, reference_no, recurrence, recurrence_parent)
    VALUES (NEW.title, NEW.description, NEW.assigned_to, NEW.category, NEW.priority, 'Not Started', current_date, nd, NEW.due_time, NEW.vehicle_no, NEW.driver_name, NEW.customer_name, NEW.loading_point, NEW.unloading_point, NEW.reference_no, NEW.recurrence, coalesce(NEW.recurrence_parent, NEW.id));
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tasks_recur_trg AFTER UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.tasks_recur();

UPDATE public.tasks SET recurrence = 'Monthly' WHERE title IN ('Reconcile FASTag - September','Reconcile diesel consumption','GSTR-1 data compilation');
INSERT INTO public.tasks(title, description, assigned_to, category, priority, assigned_date, due_date, recurrence)
SELECT 'Check today''s tanker placement', 'Daily placement review for all tankers.', id, 'Vehicle Placement', 'Normal', current_date, current_date, 'Daily' FROM public.employees WHERE name = 'Rajesh Kumar';
INSERT INTO public.tasks(title, description, assigned_to, category, priority, assigned_date, due_date, recurrence)
SELECT 'Review outstanding PODs', 'Weekly POD ageing review.', id, 'POD', 'High', current_date, current_date + 2, 'Weekly' FROM public.employees WHERE name = 'Vikram Yadav';
