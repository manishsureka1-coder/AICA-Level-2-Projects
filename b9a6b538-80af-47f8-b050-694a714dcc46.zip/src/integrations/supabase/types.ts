export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          changed_by: string | null
          created_at: string
          details: string | null
          id: string
          task_code: string | null
          task_id: string | null
        }
        Insert: {
          action: string
          changed_by?: string | null
          created_at?: string
          details?: string | null
          id?: string
          task_code?: string | null
          task_id?: string | null
        }
        Update: {
          action?: string
          changed_by?: string | null
          created_at?: string
          details?: string | null
          id?: string
          task_code?: string | null
          task_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          city: string | null
          contact_person: string | null
          created_at: string
          id: string
          name: string
          phone: string | null
        }
        Insert: {
          city?: string | null
          contact_person?: string | null
          created_at?: string
          id?: string
          name: string
          phone?: string | null
        }
        Update: {
          city?: string | null
          contact_person?: string | null
          created_at?: string
          id?: string
          name?: string
          phone?: string | null
        }
        Relationships: []
      }
      drivers: {
        Row: {
          created_at: string
          id: string
          license_no: string | null
          name: string
          phone: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          license_no?: string | null
          name: string
          phone?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          license_no?: string | null
          name?: string
          phone?: string | null
        }
        Relationships: []
      }
      employees: {
        Row: {
          active: boolean
          created_at: string
          department: string | null
          designation: string | null
          email: string | null
          id: string
          is_owner: boolean
          mobile: string | null
          name: string
          user_id: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          department?: string | null
          designation?: string | null
          email?: string | null
          id?: string
          is_owner?: boolean
          mobile?: string | null
          name: string
          user_id?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          department?: string | null
          designation?: string | null
          email?: string | null
          id?: string
          is_owner?: boolean
          mobile?: string | null
          name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      owner_todos: {
        Row: {
          created_at: string
          done: boolean
          done_at: string | null
          due_date: string | null
          employee_id: string | null
          id: string
          notes: string | null
          priority: string
          title: string
        }
        Insert: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          due_date?: string | null
          employee_id?: string | null
          id?: string
          notes?: string | null
          priority?: string
          title: string
        }
        Update: {
          created_at?: string
          done?: boolean
          done_at?: string | null
          due_date?: string | null
          employee_id?: string | null
          id?: string
          notes?: string | null
          priority?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "owner_todos_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      settings: {
        Row: {
          key: string
          value: string | null
        }
        Insert: {
          key: string
          value?: string | null
        }
        Update: {
          key?: string
          value?: string | null
        }
        Relationships: []
      }
      task_comments: {
        Row: {
          author_id: string | null
          author_name: string
          comment: string
          created_at: string
          id: string
          status_at_time: string | null
          task_id: string
        }
        Insert: {
          author_id?: string | null
          author_name: string
          comment: string
          created_at?: string
          id?: string
          status_at_time?: string | null
          task_id: string
        }
        Update: {
          author_id?: string | null
          author_name?: string
          comment?: string
          created_at?: string
          id?: string
          status_at_time?: string | null
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_comments_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "task_comments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          assigned_date: string
          assigned_to: string | null
          cancel_reason: string | null
          category: string
          completed_at: string | null
          completed_by: string | null
          created_at: string
          customer_name: string | null
          description: string | null
          driver_name: string | null
          due_date: string | null
          due_time: string | null
          id: string
          last_update_at: string
          loading_point: string | null
          priority: string
          recurrence: string
          recurrence_parent: string | null
          reference_no: string | null
          status: string
          task_code: string
          title: string
          unloading_point: string | null
          updated_at: string
          vehicle_no: string | null
        }
        Insert: {
          assigned_date?: string
          assigned_to?: string | null
          cancel_reason?: string | null
          category?: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          customer_name?: string | null
          description?: string | null
          driver_name?: string | null
          due_date?: string | null
          due_time?: string | null
          id?: string
          last_update_at?: string
          loading_point?: string | null
          priority?: string
          recurrence?: string
          recurrence_parent?: string | null
          reference_no?: string | null
          status?: string
          task_code?: string
          title: string
          unloading_point?: string | null
          updated_at?: string
          vehicle_no?: string | null
        }
        Update: {
          assigned_date?: string
          assigned_to?: string | null
          cancel_reason?: string | null
          category?: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          customer_name?: string | null
          description?: string | null
          driver_name?: string | null
          due_date?: string | null
          due_time?: string | null
          id?: string
          last_update_at?: string
          loading_point?: string | null
          priority?: string
          recurrence?: string
          recurrence_parent?: string | null
          reference_no?: string | null
          status?: string
          task_code?: string
          title?: string
          unloading_point?: string | null
          updated_at?: string
          vehicle_no?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_completed_by_fkey"
            columns: ["completed_by"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_recurrence_parent_fkey"
            columns: ["recurrence_parent"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          created_at: string
          fitness_expiry: string | null
          id: string
          insurance_expiry: string | null
          permit_expiry: string | null
          pollution_expiry: string | null
          vehicle_no: string
          vehicle_type: string | null
        }
        Insert: {
          created_at?: string
          fitness_expiry?: string | null
          id?: string
          insurance_expiry?: string | null
          permit_expiry?: string | null
          pollution_expiry?: string | null
          vehicle_no: string
          vehicle_type?: string | null
        }
        Update: {
          created_at?: string
          fitness_expiry?: string | null
          id?: string
          insurance_expiry?: string | null
          permit_expiry?: string | null
          pollution_expiry?: string | null
          vehicle_no?: string
          vehicle_type?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_owner: { Args: { _email: string; _name: string }; Returns: boolean }
      current_actor: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_owner: { Args: never; Returns: boolean }
      my_employee_id: { Args: never; Returns: string }
      owner_exists: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "owner" | "staff"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "staff"],
    },
  },
} as const
