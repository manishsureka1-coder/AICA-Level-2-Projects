import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page";
import { TaskTable } from "@/components/task-table";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";

export const Route = createFileRoute("/_app/completed")({
  head: () => ({ meta: [{ title: "Completed Tasks — MS Transport To-Do" }, { name: "description", content: "Permanent searchable archive of completed tasks." }, { property: "og:title", content: "Completed Tasks" }, { property: "og:description", content: "Completed task archive." }] }),
  component: () => {
    const { data: tasks = [] } = useTasks();
    const { data: emps = [] } = useEmployees();
    return (
      <>
        <PageHeader title="Completed Tasks" subtitle="Permanently kept with full comments and history." />
        <TaskTable tasks={tasks.filter((t) => t.status === "Completed" || t.status === "Cancelled")} names={employeeMap(emps)} defaultView="All" />
      </>
    );
  },
});
