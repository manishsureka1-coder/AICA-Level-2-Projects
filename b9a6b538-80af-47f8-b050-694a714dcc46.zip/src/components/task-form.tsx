import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES, PRIORITIES, RECURRENCES } from "@/lib/constants";
import { useCustomers, useDrivers, useEmployees, useVehicles } from "@/lib/data";
import { type Task, todayISO } from "@/lib/task-utils";

const schema = z.object({
  title: z.string().trim().min(3, "Title is too short").max(200),
  description: z.string().max(4000).optional().nullable(),
  assigned_to: z.string().uuid("Choose who this is assigned to"),
  category: z.string(),
  priority: z.string(),
  assigned_date: z.string(),
  due_date: z.string().min(1, "Choose a due date"),
  due_time: z.string().optional().nullable(),
  vehicle_no: z.string().max(30).optional().nullable(),
  driver_name: z.string().max(100).optional().nullable(),
  customer_name: z.string().max(150).optional().nullable(),
  loading_point: z.string().max(150).optional().nullable(),
  unloading_point: z.string().max(150).optional().nullable(),
  reference_no: z.string().max(100).optional().nullable(),
  recurrence: z.string(),
});
export type TaskInput = z.infer<typeof schema>;

export function TaskForm({ initial, onSubmit, submitLabel }: { initial?: Partial<Task>; onSubmit: (v: TaskInput) => Promise<void>; submitLabel: string }) {
  const { data: emps = [] } = useEmployees();
  const { data: vehicles = [] } = useVehicles();
  const { data: customers = [] } = useCustomers();
  const { data: drivers = [] } = useDrivers();
  const [v, setV] = useState({
    title: initial?.title ?? "", description: initial?.description ?? "", assigned_to: initial?.assigned_to ?? "",
    category: initial?.category ?? "Other", priority: initial?.priority ?? "Normal",
    assigned_date: initial?.assigned_date ?? todayISO(), due_date: initial?.due_date ?? todayISO(),
    due_time: initial?.due_time?.slice(0, 5) ?? "", vehicle_no: initial?.vehicle_no ?? "", driver_name: initial?.driver_name ?? "",
    customer_name: initial?.customer_name ?? "", loading_point: initial?.loading_point ?? "", unloading_point: initial?.unloading_point ?? "",
    reference_no: initial?.reference_no ?? "", recurrence: initial?.recurrence ?? "None",
  });
  const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: { target: { value: string } }) => setV((p) => ({ ...p, [k]: e.target.value }));
  const sel = (k: string) => (val: string) => setV((p) => ({ ...p, [k]: val }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(v);
    if (!parsed.success) { toast.error(parsed.error.issues[0]?.message ?? "Invalid input"); return; }
    const clean = Object.fromEntries(Object.entries(parsed.data).map(([k, x]) => [k, x === "" ? null : x])) as TaskInput;
    setBusy(true);
    try { await onSubmit(clean); } catch (err) { toast.error((err as Error).message); }
    setBusy(false);
  };

  return (
    <form onSubmit={submit} className="card-surface space-y-6 p-6">
      <section className="grid gap-4 md:grid-cols-2">
        <Field label="Task title *" className="md:col-span-2"><Input value={v.title} onChange={set("title")} placeholder="Collect POD for WB23F1234" /></Field>
        <Field label="Detailed description" className="md:col-span-2"><Textarea rows={4} value={v.description} onChange={set("description")} /></Field>
        <Field label="Assigned to *">
          <Select value={v.assigned_to} onValueChange={sel("assigned_to")}>
            <SelectTrigger><SelectValue placeholder="Choose employee" /></SelectTrigger>
            <SelectContent>{emps.filter((e) => e.active).map((e) => <SelectItem key={e.id} value={e.id}>{e.name} — {e.designation}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
        <Field label="Category"><Pick value={v.category} onChange={sel("category")} items={CATEGORIES} /></Field>
        <Field label="Priority"><Pick value={v.priority} onChange={sel("priority")} items={PRIORITIES} /></Field>
        <Field label="Repeat"><Pick value={v.recurrence} onChange={sel("recurrence")} items={RECURRENCES} /></Field>
        <Field label="Assignment date"><Input type="date" value={v.assigned_date} onChange={set("assigned_date")} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Due date *"><Input type="date" value={v.due_date} onChange={set("due_date")} /></Field>
          <Field label="Due time"><Input type="time" value={v.due_time} onChange={set("due_time")} /></Field>
        </div>
      </section>
      <section>
        <div className="mb-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Transport details (optional)</div>
        <div className="grid gap-4 md:grid-cols-3">
          <Field label="Vehicle number"><Input list="veh" value={v.vehicle_no} onChange={set("vehicle_no")} /><datalist id="veh">{vehicles.map((x) => <option key={x.id} value={x.vehicle_no} />)}</datalist></Field>
          <Field label="Driver"><Input list="drv" value={v.driver_name} onChange={set("driver_name")} /><datalist id="drv">{drivers.map((x) => <option key={x.id} value={x.name} />)}</datalist></Field>
          <Field label="Customer"><Input list="cus" value={v.customer_name} onChange={set("customer_name")} /><datalist id="cus">{customers.map((x) => <option key={x.id} value={x.name} />)}</datalist></Field>
          <Field label="Loading point"><Input value={v.loading_point} onChange={set("loading_point")} /></Field>
          <Field label="Unloading point / destination"><Input value={v.unloading_point} onChange={set("unloading_point")} /></Field>
          <Field label="Reference no. (LR / invoice / PO / tender / e-way bill)"><Input value={v.reference_no} onChange={set("reference_no")} /></Field>
        </div>
      </section>
      <Button type="submit" disabled={busy} className="bg-accent text-accent-foreground hover:bg-accent/90">{submitLabel}</Button>
    </form>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return <div className={`space-y-1.5 ${className ?? ""}`}><Label className="text-xs">{label}</Label>{children}</div>;
}
function Pick({ value, onChange, items }: { value: string; onChange: (v: string) => void; items: readonly string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger><SelectValue /></SelectTrigger>
      <SelectContent>{items.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
    </Select>
  );
}
