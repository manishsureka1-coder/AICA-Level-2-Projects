import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { OwnerOnly, PageHeader } from "@/components/page";
import { TaskForm } from "@/components/task-form";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { useInvalidate } from "@/lib/data";

export const Route = createFileRoute("/_app/tasks/new")({
  head: () => ({ meta: [{ title: "Add Task — MS Transport To-Do" }, { name: "description", content: "Create and assign a new task." }, { property: "og:title", content: "Add Task" }, { property: "og:description", content: "Create a task." }] }),
  component: NewTask,
});

function NewTask() {
  const { isOwner } = useSession();
  const navigate = useNavigate();
  const invalidate = useInvalidate();
  if (!isOwner) return <OwnerOnly />;
  return (
    <>
      <PageHeader title="Add New Task" subtitle="Task ID is generated automatically (MST-YYYY-00001)." />
      <TaskForm submitLabel="Create task" onSubmit={async (v) => {
        const { data, error } = await supabase.from("tasks").insert(v).select("id, task_code").single();
        if (error) throw new Error(error.message);
        await invalidate("tasks", "audit");
        toast.success(`Task ${data.task_code} created`);
        navigate({ to: "/tasks/$id", params: { id: data.id } });
      }} />
    </>
  );
}
