import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const aiManagementSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ facts: z.string().max(60000), question: z.string().max(1000).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "owner" });
    if (!isOwner) throw new Error("Only the owner can use the AI assistant");
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { text: "", error: "AI is not configured. The rule-based observations above still work." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You are a management assistant for an Indian transport company owner (a Chartered Accountant). Analyse the task data and give concise, factual management observations and recommended actions. Use bullet points, Indian date format, ₹ for money. Never invent data not present." },
          { role: "user", content: `${data.question ? "Question: " + data.question + "\n\n" : "Give today's management observations, top risks and 5 recommended actions.\n\n"}Task data (JSON):\n${data.facts}` },
        ],
      }),
    });
    if (res.status === 429) return { text: "", error: "AI is busy right now — please try again in a minute." };
    if (res.status === 402) return { text: "", error: "AI credits are exhausted. Add credits in workspace settings." };
    if (!res.ok) return { text: "", error: `AI request failed (${res.status}).` };
    const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { text: j.choices?.[0]?.message?.content ?? "", error: null };
  });
