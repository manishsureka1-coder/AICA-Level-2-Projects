ALTER TABLE public.owner_todos ADD COLUMN IF NOT EXISTS employee_id uuid REFERENCES public.employees(id) ON DELETE CASCADE DEFAULT public.my_employee_id();
UPDATE public.owner_todos SET employee_id = (SELECT id FROM public.employees WHERE is_owner ORDER BY created_at LIMIT 1) WHERE employee_id IS NULL;
DROP POLICY IF EXISTS "owner todos" ON public.owner_todos;
CREATE POLICY "own todos" ON public.owner_todos FOR ALL TO authenticated USING (employee_id = public.my_employee_id()) WITH CHECK (employee_id = public.my_employee_id());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.owner_todos TO authenticated;
GRANT ALL ON public.owner_todos TO service_role;