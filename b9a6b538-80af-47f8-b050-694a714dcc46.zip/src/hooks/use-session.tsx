import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Employee } from "@/lib/task-utils";

type Ctx = {
  loading: boolean;
  session: Session | null;
  me: Employee | null;
  isOwner: boolean;
  refresh: () => Promise<void>;
};
const SessionCtx = createContext<Ctx>({ loading: true, session: null, me: null, isOwner: false, refresh: async () => {} });

export function SessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [me, setMe] = useState<Employee | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async (s: Session | null) => {
    setSession(s);
    if (!s) { setMe(null); setIsOwner(false); setLoading(false); return; }
    const [{ data: emp }, { data: roles }] = await Promise.all([
      supabase.from("employees").select("*").eq("user_id", s.user.id).maybeSingle(),
      supabase.from("user_roles").select("role").eq("user_id", s.user.id),
    ]);
    setMe(emp ?? null);
    setIsOwner(!!roles?.some((r) => r.role === "owner"));
    setLoading(false);
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setTimeout(() => void load(s), 0);
    });
    supabase.auth.getSession().then(({ data }) => load(data.session));
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <SessionCtx.Provider value={{ loading, session, me, isOwner, refresh: () => load(session) }}>
      {children}
    </SessionCtx.Provider>
  );
}

export const useSession = () => useContext(SessionCtx);
