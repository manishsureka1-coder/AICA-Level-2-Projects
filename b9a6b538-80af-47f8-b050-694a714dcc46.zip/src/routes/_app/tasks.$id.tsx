import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Pencil } from "lucide-react";
import { PageHeader } from "@/components/page";
import { Pill, PriorityBadge, StatusBadge } from "@/components/badges";
import { TaskForm } from "@/components/task-form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { STATUSES } from "@/lib/constants";
import { employeeMap, useAudit, useComments, useEmployees, useInvalidate, useTasks } from "@/lib/data";
import { daysOverdue, daysPending, fmtDate, fmtDateTime, isEscalated, isOpen, isOverdue, noUpdateDays } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/tasks/$id")({
  head: () => ({ meta: [{ title: "Task — MS Transport To-Do" }, { name: "description", content: "Task details, daily comments and history." }, { property: "og:title", content: "Task details" }, { property: "og:description", content: "Task details." }] }),
  component: TaskPage,
});

function TaskPage() {
  const { id } = Route.useParams();
  const { isOwner, me } = useSession();
  const { data: tasks = [], isLoading } = useTasks();
  const { data: emps = [] } = useEmployees();
  const { data: comments = [] } = useComments(id);
  const { data: audit = [] } = useAudit(id);
  const invalidate = useInvalidate();
  const [comment, setComment] = useState("");
  const [status, setStatus] = useState<string>("");
  const [reason, setReason] = useState("");
  const [editing, setEditing] = useState(false);
  const names = employeeMap(emps);
  const t = tasks.find((x) => x.id === id);
  if (isLoading) return <div className="text-muted-foreground">Loading…</div>;
  if (!t) return <div className="card-surface p-10 text-center text-muted-foreground">Task not found or not assigned to you.</div>;

  const refresh = () => invalidate("tasks", "comments", "audit");

  const addComment = async () => {
    const text = comment.trim();
    if (!text || text.length > 2000) { toast.error("Write a comment (max 2000 characters)"); return; }
    if (!me) { toast.error("Your login is not linked to an employee"); return; }
    const { error } = await supabase.from("task_comments").insert({ task_id: t.id, author_id: me.id, author_name: me.name, comment: text, status_at_time: t.status });
    if (error) return toast.error(error.message);
    setComment(""); toast.success("Comment added"); refresh();
  };

  const changeStatus = async () => {
    if (!status || status === t.status) return;
    if (status === "Cancelled" && !reason.trim()) { toast.error("Please record a reason for cancelling"); return; }
    const { error } = await supabase.from("tasks").update({ status, cancel_reason: status === "Cancelled" ? reason.trim() : t.cancel_reason }).eq("id", t.id);
    if (error) return toast.error(error.message);
    toast.success(`Status changed to ${status}`); setStatus(""); setReason(""); refresh();
  };

  return (
    <>
      <Link to={isOwner ? "/tasks" : "/my-tasks"} className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" />Back</Link>
      <PageHeader title={t.title} subtitle={`${t.task_code} · ${t.category}`}>
        {isOwner && <Button variant="outline" onClick={() => setEditing(!editing)}><Pencil className="mr-1 h-4 w-4" />{editing ? "Close edit" : "Edit / reassign"}</Button>}
      </PageHeader>

      {editing && isOwner && (
        <div className="mb-6">
          <TaskForm initial={t} submitLabel="Save changes" onSubmit={async (v) => {
            const { error } = await supabase.from("tasks").update(v).eq("id", t.id);
            if (error) throw new Error(error.message);
            toast.success("Task updated"); setEditing(false); refresh();
          }} />
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <div className="card-surface p-5">
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <StatusBadge status={t.status} /><PriorityBadge priority={t.priority} />
              {isEscalated(t) && <Pill tone="solidDanger">Escalated</Pill>}
              {isOverdue(t) && <Pill tone="danger">Overdue {daysOverdue(t)} day(s)</Pill>}
              {isOpen(t) && <Pill tone="neutral">Pending for {daysPending(t)} days</Pill>}
              {t.recurrence !== "None" && <Pill tone="info">Repeats {t.recurrence}</Pill>}
            </div>
            {t.description && <p className="mb-4 whitespace-pre-wrap text-sm">{t.description}</p>}
            <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm md:grid-cols-3">
              <D k="Assigned to" v={names[t.assigned_to ?? ""]} />
              <D k="Original assignment date" v={fmtDate(t.assigned_date)} />
              <D k="Current pending since" v={isOpen(t) ? fmtDate(t.assigned_date) : "—"} />
              <D k="Due" v={`${fmtDate(t.due_date)}${t.due_time ? " " + t.due_time.slice(0, 5) : ""}`} />
              <D k="Last update" v={`${fmtDateTime(t.last_update_at)} (${noUpdateDays(t)}d ago)`} />
              <D k="Vehicle" v={t.vehicle_no} />
              <D k="Driver" v={t.driver_name} />
              <D k="Customer" v={t.customer_name} />
              <D k="Loading point" v={t.loading_point} />
              <D k="Unloading / destination" v={t.unloading_point} />
              <D k="Reference" v={t.reference_no} />
              {t.completed_at && <D k="Completed" v={`${fmtDateTime(t.completed_at)} by ${names[t.completed_by ?? ""] ?? "—"}`} />}
              {t.cancel_reason && <D k="Cancel reason" v={t.cancel_reason} />}
            </dl>
          </div>

          <div className="card-surface">
            <div className="border-b px-5 py-3 font-display text-lg font-bold uppercase">Daily comments</div>
            <ol className="divide-y">
              {comments.map((c) => (
                <li key={c.id} className="px-5 py-3">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">{fmtDateTime(c.created_at)}</span>· {c.author_name}
                    {c.status_at_time && <StatusBadge status={c.status_at_time} />}
                  </div>
                  <p className="mt-1 whitespace-pre-wrap text-sm">{c.comment}</p>
                </li>
              ))}
              {comments.length === 0 && <li className="px-5 py-6 text-center text-sm text-muted-foreground">No comments yet.</li>}
            </ol>
            <div className="space-y-2 border-t p-4">
              <Textarea rows={3} placeholder="Today's update — e.g. Vehicle reached Haldia. Loading expected tomorrow morning." value={comment} onChange={(e) => setComment(e.target.value)} maxLength={2000} />
              <Button onClick={addComment}>Add daily comment</Button>
              <p className="text-xs text-muted-foreground">Comments are never overwritten — the full history is kept.</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card-surface space-y-3 p-5">
            <div className="font-display text-lg font-bold uppercase">Update status</div>
            <Select value={status || t.status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.filter((s) => isOwner || s !== "Cancelled").map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
            {status === "Cancelled" && <Input placeholder="Reason for cancelling (required)" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={300} />}
            <Button className="w-full" onClick={changeStatus} disabled={!status || status === t.status}>Save status</Button>
            {isOwner && (
              <Button variant="outline" className="w-full" onClick={async () => {
                const { error } = await supabase.from("tasks").update({ status: "Completed" }).eq("id", t.id);
                if (error) toast.error(error.message); else { toast.success("Marked completed"); refresh(); }
              }} disabled={t.status === "Completed"}>Mark completed</Button>
            )}
          </div>
          <div className="card-surface">
            <div className="border-b px-5 py-3 font-display text-lg font-bold uppercase">Audit history</div>
            <ol className="max-h-[480px] divide-y overflow-y-auto text-sm">
              {audit.map((a) => (
                <li key={a.id} className="px-5 py-2.5">
                  <div className="text-xs text-muted-foreground">{fmtDateTime(a.created_at)} · {a.changed_by}</div>
                  <div><b>{a.action}</b> — {a.details}</div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </>
  );
}

function D({ k, v }: { k: string; v?: string | null }) {
  return <div><dt className="text-[11px] uppercase tracking-wider text-muted-foreground">{k}</dt><dd className="font-medium">{v || "—"}</dd></div>;
}
