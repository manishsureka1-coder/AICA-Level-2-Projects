import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { PageHeader } from "@/components/page";
import { TaskTable } from "@/components/task-table";
import { employeeMap, useComments, useEmployees, useTasks } from "@/lib/data";
import { searchText } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/search")({
  validateSearch: (s) => z.object({ q: z.string().catch("") }).parse(s),
  head: () => ({ meta: [{ title: "Search — MS Transport To-Do" }, { name: "description", content: "Search all tasks and comments." }, { property: "og:title", content: "Search" }, { property: "og:description", content: "Global search." }] }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  const { data: comments = [] } = useComments();
  const names = employeeMap(emps);
  const ql = q.trim().toLowerCase();
  const byComment = new Set(comments.filter((c) => c.comment.toLowerCase().includes(ql)).map((c) => c.task_id));
  const hits = ql ? tasks.filter((t) => byComment.has(t.id) || searchText(t, names[t.assigned_to ?? ""]).includes(ql)) : [];
  return (
    <>
      <PageHeader title={`Search: ${q || "—"}`} subtitle={`${hits.length} task(s) found across vehicle, customer, driver, LR, invoice, PO, tender, task ID, description, employee and comments.`} />
      <TaskTable key={q} tasks={hits} names={names} defaultView="All" />
    </>
  );
}
