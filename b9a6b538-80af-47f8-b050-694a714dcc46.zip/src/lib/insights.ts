import { type Task, type Employee, daysPending, isOpen, isOverdue, isStale, isEscalated, isDueToday, noUpdateDays } from "./task-utils";

export type Insight = { level: "critical" | "warning" | "info"; text: string };

export function ruleInsights(tasks: Task[], emps: Employee[]): Insight[] {
  const out: Insight[] = [];
  const open = tasks.filter(isOpen);
  const name = (id: string | null) => emps.find((e) => e.id === id)?.name ?? "Unassigned";

  const critOver = open.filter((t) => t.priority === "Critical" && isOverdue(t));
  if (critOver.length) out.push({ level: "critical", text: `${critOver.length} critical task(s) are overdue: ${critOver.map((t) => t.title).slice(0, 3).join("; ")}.` });

  const esc = open.filter(isEscalated);
  if (esc.length) out.push({ level: "critical", text: `${esc.length} task(s) are escalated (overdue beyond 2 days or critical).` });

  const byCat = (cat: string, days: number, label: string) => {
    const n = open.filter((t) => t.category === cat && daysPending(t) > days).length;
    if (n) out.push({ level: "warning", text: `${n} ${label} task(s) are pending for more than ${days} days.` });
  };
  byCat("POD", 3, "POD collection");
  byCat("Payment Collection", 3, "payment follow-up");
  byCat("Billing", 3, "billing");

  const pay = open.filter((t) => t.category === "Payment Collection" || t.status === "Waiting for Payment");
  if (pay.length) out.push({ level: "warning", text: `${pay.length} payment follow-up(s) require attention.` });

  const byVeh: Record<string, number> = {};
  open.forEach((t) => { if (t.vehicle_no) byVeh[t.vehicle_no] = (byVeh[t.vehicle_no] ?? 0) + 1; });
  Object.entries(byVeh).filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1])
    .forEach(([v, n]) => out.push({ level: "warning", text: `Vehicle ${v} has ${n} unresolved tasks.` }));

  const staleBy: Record<string, number> = {};
  open.filter(isStale).forEach((t) => { const k = name(t.assigned_to); staleBy[k] = (staleBy[k] ?? 0) + 1; });
  Object.entries(staleBy).sort((a, b) => b[1] - a[1])
    .forEach(([n, c]) => out.push({ level: c >= 3 ? "warning" : "info", text: `${n} has ${c} task(s) with no update for more than 48 hours.` }));

  const overBy: Record<string, number> = {};
  open.filter(isOverdue).forEach((t) => { const k = name(t.assigned_to); overBy[k] = (overBy[k] ?? 0) + 1; });
  const top = Object.entries(overBy).sort((a, b) => b[1] - a[1])[0];
  if (top) out.push({ level: "info", text: `${top[0]} has the most overdue tasks (${top[1]}).` });

  const today = open.filter(isDueToday).length;
  out.push({ level: "info", text: `${today} task(s) are due today; ${open.length} open in total.` });

  const longest = [...open].sort((a, b) => daysPending(b) - daysPending(a))[0];
  if (longest) out.push({ level: "info", text: `Longest pending: "${longest.title}" (${daysPending(longest)} days, ${name(longest.assigned_to)}, last update ${noUpdateDays(longest)}d ago).` });

  return out;
}
