import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { PriorityBadge } from "@/components/badges";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { PRIORITIES } from "@/lib/constants";
import { useInvalidate, useTodos } from "@/lib/data";
import { addDaysISO, fmtDate, todayISO } from "@/lib/task-utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/my-todo")({
  head: () => ({ meta: [{ title: "My To-Do — MS Transport" }, { name: "description", content: "Your private personal to-do list." }, { property: "og:title", content: "My To-Do" }, { property: "og:description", content: "Personal to-do." }] }),
  component: Todo,
});

const TABS = ["Today", "Tomorrow", "This Week", "Overdue", "Completed", "All open"] as const;

function Todo() {
  const { me } = useSession();
  const { data: todos = [] } = useTodos();
  const invalidate = useInvalidate();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Today");
  const [f, setF] = useState({ title: "", due_date: todayISO(), priority: "Normal" });
  if (!me) return <OwnerOnly />;
  const t0 = todayISO(), t1 = addDaysISO(t0, 1), t7 = addDaysISO(t0, 7);
  const list = todos.filter((x) => {
    if (tab === "Completed") return x.done;
    if (x.done) return false;
    const d = x.due_date ?? "";
    if (tab === "Today") return d === t0;
    if (tab === "Tomorrow") return d === t1;
    if (tab === "This Week") return d >= t0 && d <= t7;
    if (tab === "Overdue") return !!d && d < t0;
    return true;
  });
  const add = async () => {
    if (!f.title.trim()) return;
    const { error } = await supabase.from("owner_todos").insert({ ...f, title: f.title.trim().slice(0, 300) });
    if (error) return toast.error(error.message);
    setF({ ...f, title: "" }); invalidate("todos");
  };
  return (
    <>
      <PageHeader title={`My To-Do — ${me.name}`} subtitle="Your private list. Only you can see it." />
      <div className="card-surface mb-4 flex flex-wrap gap-2 p-4">
        <Input className="min-w-64 flex-1" placeholder="e.g. Call customer regarding new contract" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} onKeyDown={(e) => e.key === "Enter" && add()} />
        <Input type="date" className="w-40" value={f.due_date} onChange={(e) => setF({ ...f, due_date: e.target.value })} />
        <Select value={f.priority} onValueChange={(v) => setF({ ...f, priority: v })}><SelectTrigger className="w-32"><SelectValue /></SelectTrigger><SelectContent>{PRIORITIES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select>
        <Button onClick={add}>Add</Button>
      </div>
      <div className="mb-3 flex flex-wrap gap-1">
        {TABS.map((x) => <button key={x} onClick={() => setTab(x)} className={cn("rounded px-3 py-1.5 text-xs font-semibold", tab === x ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground")}>{x}</button>)}
      </div>
      <ul className="card-surface divide-y">
        {list.map((x) => (
          <li key={x.id} className="flex items-center gap-3 px-4 py-3">
            <Checkbox checked={x.done} onCheckedChange={async (c) => { await supabase.from("owner_todos").update({ done: !!c, done_at: c ? new Date().toISOString() : null }).eq("id", x.id); invalidate("todos"); }} />
            <span className={cn("flex-1", x.done && "text-muted-foreground line-through")}>{x.title}</span>
            <PriorityBadge priority={x.priority} />
            <span className={cn("w-24 text-right text-xs", !x.done && x.due_date && x.due_date < t0 && "font-semibold text-destructive")}>{fmtDate(x.due_date)}</span>
            <button onClick={async () => { await supabase.from("owner_todos").delete().eq("id", x.id); invalidate("todos"); }}><Trash2 className="h-4 w-4 text-muted-foreground" /></button>
          </li>
        ))}
        {list.length === 0 && <li className="px-4 py-8 text-center text-muted-foreground">Nothing here.</li>}
      </ul>
    </>
  );
}
