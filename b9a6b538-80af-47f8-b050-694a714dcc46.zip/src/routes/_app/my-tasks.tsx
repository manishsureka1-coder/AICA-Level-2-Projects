import { createFileRoute } from "@tanstack/react-router";
import { ListTodo, CalendarClock, AlarmClock, CheckCircle2, Repeat, Siren } from "lucide-react";
import { PageHeader } from "@/components/page";
import { StatCard } from "@/components/stat-card";
import { TaskTable } from "@/components/task-table";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";
import { type Task, isCarriedForward, isCritical, isDueToday, isOpen, isOverdue } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/my-tasks")({
  head: () => ({ meta: [{ title: "My Tasks — MS Transport To-Do" }, { name: "description", content: "Tasks assigned to me." }, { property: "og:title", content: "My Tasks" }, { property: "og:description", content: "Tasks assigned to me." }] }),
  component: MyTasksView,
});

export function MyTasksView() {
  const { me } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  const mine = tasks.filter((t) => t.assigned_to === me?.id);
  return <EmployeeBoard title={`My Tasks — ${me?.name ?? ""}`} subtitle={`${me?.designation ?? ""} · ${me?.department ?? ""}`} tasks={mine} names={employeeMap(emps)} />;
}

export function EmployeeBoard({ title, subtitle, tasks, names }: { title: string; subtitle?: string | undefined; tasks: Task[]; names: Record<string, string> }) {
  const open = tasks.filter(isOpen);
  return (
    <>
      <PageHeader title={title} subtitle={subtitle} />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        <StatCard label="Total assigned" value={tasks.length} icon={ListTodo} />
        <StatCard label="Open" value={open.length} icon={ListTodo} tone="accent" />
        <StatCard label="Due today" value={open.filter(isDueToday).length} icon={CalendarClock} tone="warning" />
        <StatCard label="Overdue" value={open.filter(isOverdue).length} icon={AlarmClock} tone="danger" />
        <StatCard label="Completed" value={tasks.filter((t) => t.status === "Completed").length} icon={CheckCircle2} tone="success" />
        <StatCard label="Carried forward" value={open.filter(isCarriedForward).length} icon={Repeat} />
        <StatCard label="Critical" value={open.filter(isCritical).length} icon={Siren} tone="danger" />
      </div>
      <TaskTable tasks={tasks} names={names} showAssignee={false} />
    </>
  );
}
