import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { useCustomers, useInvalidate, useTasks } from "@/lib/data";
import { isOpen, isOverdue } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/customers")({
  head: () => ({ meta: [{ title: "Customers — MS Transport To-Do" }, { name: "description", content: "Customers and their open tasks." }, { property: "og:title", content: "Customers" }, { property: "og:description", content: "Customer list." }] }),
  component: Customers,
});

function Customers() {
  const { isOwner } = useSession();
  const { data: customers = [] } = useCustomers();
  const { data: tasks = [] } = useTasks();
  const invalidate = useInvalidate();
  const [f, setF] = useState({ name: "", contact_person: "", phone: "", city: "" });
  const add = async (): Promise<void> => {
    if (!f.name.trim()) { toast.error("Name required"); return; }
    const { error } = await supabase.from("customers").insert({ ...f, name: f.name.trim() });
    if (error) { toast.error(error.message); return; }
    toast.success("Customer added"); setF({ name: "", contact_person: "", phone: "", city: "" }); invalidate("customers");
  };
  return (
    <>
      <PageHeader title="Customers" />
      {isOwner && (
        <div className="card-surface mb-4 grid gap-2 p-4 md:grid-cols-5">
          {(["name", "contact_person", "phone", "city"] as const).map((k) => (
            <Input key={k} placeholder={k.replace("_", " ")} value={f[k]} maxLength={150} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
          ))}
          <Button onClick={add}>Add customer</Button>
        </div>
      )}
      <div className="card-surface overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr><th className="px-4 py-2">Customer</th><th className="px-3 py-2">Contact</th><th className="px-3 py-2">City</th><th className="px-3 py-2">Open tasks</th><th className="px-3 py-2">Overdue</th></tr>
          </thead>
          <tbody>
            {customers.map((c) => {
              const ct = tasks.filter((t) => t.customer_name === c.name && isOpen(t));
              return (
                <tr key={c.id} className="border-t">
                  <td className="px-4 py-2 font-semibold"><Link to="/search" search={{ q: c.name }} className="text-primary hover:underline">{c.name}</Link></td>
                  <td className="px-3 py-2">{c.contact_person} {c.phone && `· ${c.phone}`}</td><td className="px-3 py-2">{c.city}</td>
                  <td className="px-3 py-2 font-mono">{ct.length}</td><td className="px-3 py-2 font-mono">{ct.filter(isOverdue).length}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
