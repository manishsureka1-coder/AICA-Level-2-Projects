import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Database, Download, ShieldCheck } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { exportExcel } from "@/lib/exports";
import { fmtDate, fmtDateTime } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/settings")({
  head: () => ({ meta: [{ title: "Settings & Backup — MS Transport To-Do" }, { name: "description", content: "Export all data and backup." }, { property: "og:title", content: "Settings" }, { property: "og:description", content: "Settings and backup." }] }),
  component: Settings,
});

function Settings() {
  const { isOwner } = useSession();
  const [busy, setBusy] = useState(false);
  if (!isOwner) return <OwnerOnly />;

  const exportAll = async () => {
    setBusy(true);
    try {
      const [t, e, c, v, cu, a, d] = await Promise.all([
        supabase.from("tasks").select("*").limit(10000), supabase.from("employees").select("*"),
        supabase.from("task_comments").select("*").limit(20000), supabase.from("vehicles").select("*"),
        supabase.from("customers").select("*"), supabase.from("audit_log").select("*").order("created_at").limit(20000),
        supabase.from("drivers").select("*"),
      ]);
      const names = Object.fromEntries((e.data ?? []).map((x) => [x.id, x.name]));
      const tasks = t.data ?? [];
      const codes = Object.fromEntries(tasks.map((x) => [x.id, x.task_code]));
      const tcols = ["Task ID", "Title", "Description", "Assigned to", "Category", "Priority", "Status", "Assigned", "Due", "Vehicle", "Driver", "Customer", "Loading", "Unloading", "Reference", "Recurrence", "Completed at", "Completed by", "Cancel reason"];
      const trow = (x: (typeof tasks)[number]) => [x.task_code, x.title, x.description, names[x.assigned_to ?? ""], x.category, x.priority, x.status, fmtDate(x.assigned_date), fmtDate(x.due_date), x.vehicle_no, x.driver_name, x.customer_name, x.loading_point, x.unloading_point, x.reference_no, x.recurrence, fmtDateTime(x.completed_at), names[x.completed_by ?? ""] ?? "", x.cancel_reason];
      const stamp = new Date().toISOString().slice(0, 16).replace("T", "_").replace(":", "");
      await exportExcel(`manish_transport_todo_backup_${stamp}.xlsx`, [
        { name: "Tasks", columns: tcols, rows: tasks.filter((x) => x.status !== "Completed").map(trow) },
        { name: "Completed Tasks", columns: tcols, rows: tasks.filter((x) => x.status === "Completed").map(trow) },
        { name: "Employees", columns: ["Name", "Designation", "Department", "Mobile", "Email", "Active"], rows: (e.data ?? []).map((x) => [x.name, x.designation, x.department, x.mobile, x.email, x.active ? "Yes" : "No"]) },
        { name: "Comments", columns: ["Task ID", "Date & time", "User", "Status at time", "Comment"], rows: (c.data ?? []).map((x) => [codes[x.task_id], fmtDateTime(x.created_at), x.author_name, x.status_at_time, x.comment]) },
        { name: "Vehicles", columns: ["Vehicle", "Type", "Insurance", "Fitness", "Pollution", "Permit"], rows: (v.data ?? []).map((x) => [x.vehicle_no, x.vehicle_type, fmtDate(x.insurance_expiry), fmtDate(x.fitness_expiry), fmtDate(x.pollution_expiry), fmtDate(x.permit_expiry)]) },
        { name: "Customers", columns: ["Name", "Contact", "Phone", "City"], rows: (cu.data ?? []).map((x) => [x.name, x.contact_person, x.phone, x.city]) },
        { name: "Drivers", columns: ["Name", "Phone", "Licence"], rows: (d.data ?? []).map((x) => [x.name, x.phone, x.license_no]) },
        { name: "Audit Trail", columns: ["Date & time", "Task ID", "Action", "Details", "Changed by"], rows: (a.data ?? []).map((x) => [fmtDateTime(x.created_at), x.task_code, x.action, x.details, x.changed_by]) },
      ]);
      toast.success("Backup downloaded");
    } catch (err) { toast.error((err as Error).message); }
    setBusy(false);
  };

  return (
    <>
      <PageHeader title="Settings & Backup" />
      <div className="grid gap-4 md:grid-cols-2">
        <div className="card-surface p-6">
          <Download className="mb-3 h-6 w-6 text-primary" />
          <h2 className="text-xl font-bold uppercase">Backup database</h2>
          <p className="mb-4 mt-1 text-sm text-muted-foreground">Download a timestamped Excel workbook with Tasks, Completed Tasks, Employees, Comments, Vehicles, Customers, Drivers and Audit Trail.</p>
          <Button onClick={exportAll} disabled={busy} className="bg-accent text-accent-foreground hover:bg-accent/90">{busy ? "Preparing…" : "Backup database (Excel)"}</Button>
        </div>
        <div className="card-surface p-6">
          <Database className="mb-3 h-6 w-6 text-primary" />
          <h2 className="text-xl font-bold uppercase">Automatic cloud backups</h2>
          <p className="mt-1 text-sm text-muted-foreground">The database runs in the cloud and is backed up automatically, so nothing is lost if your computer fails. Completed tasks and history are never deleted.</p>
        </div>
        <div className="card-surface p-6 md:col-span-2">
          <ShieldCheck className="mb-3 h-6 w-6 text-primary" />
          <h2 className="text-xl font-bold uppercase">Internal controls in place</h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
            <li>Passwords are stored hashed; staff log in with their own accounts.</li>
            <li>Staff see only their own tasks and can only update status and add comments.</li>
            <li>Every assignment, reassignment, due-date, priority and status change is written to the audit trail by the database itself.</li>
            <li>Cancelling a task requires a recorded reason. Comments can never be edited or overwritten.</li>
          </ul>
        </div>
      </div>
    </>
  );
}
