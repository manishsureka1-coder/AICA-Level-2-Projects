import { Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function StatCard({
  label, value, icon: Icon, tone = "default", to, search,
}: {
  label: string; value: number | string; icon: LucideIcon;
  tone?: "default" | "danger" | "warning" | "success" | "accent";
  to?: string; search?: Record<string, string>;
}) {
  const toneCls = {
    default: "text-primary bg-primary/10",
    danger: "text-destructive bg-destructive/10",
    warning: "text-warning-foreground bg-warning/25",
    success: "text-success bg-success/15",
    accent: "text-accent-foreground bg-accent/40",
  }[tone];
  const body = (
    <div className={cn("card-surface flex items-center gap-4 p-4 transition-colors", to && "hover:border-accent")}>
      <div className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-md", toneCls)}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0">
        <div className="font-display text-3xl font-bold leading-none text-foreground">{value}</div>
        <div className="mt-1 truncate text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      </div>
    </div>
  );
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return to ? <Link to={to as any} search={search as any}>{body}</Link> : body;
}
