CREATE TYPE public.app_role AS ENUM ('owner','staff');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
CREATE OR REPLACE FUNCTION public.is_owner() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(auth.uid(), 'owner')
$$;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.is_owner());

CREATE TABLE public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE,
  name text NOT NULL,
  designation text,
  department text,
  mobile text,
  email text,
  is_owner boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employees TO authenticated;
GRANT ALL ON public.employees TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.my_employee_id() RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM public.employees WHERE user_id = auth.uid() LIMIT 1
$$;

CREATE POLICY "employees readable" ON public.employees FOR SELECT TO authenticated USING (true);
CREATE POLICY "owner manages employees" ON public.employees FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

CREATE TABLE public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  contact_person text, phone text, city text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_no text NOT NULL UNIQUE,
  vehicle_type text,
  insurance_expiry date, fitness_expiry date, pollution_expiry date, permit_expiry date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.drivers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL, phone text, license_no text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.settings (
  key text PRIMARY KEY, value text
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customers, public.vehicles, public.drivers, public.settings TO authenticated;
GRANT ALL ON public.customers, public.vehicles, public.drivers, public.settings TO service_role;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read customers" ON public.customers FOR SELECT TO authenticated USING (true);
CREATE POLICY "owner customers" ON public.customers FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE POLICY "read vehicles" ON public.vehicles FOR SELECT TO authenticated USING (true);
CREATE POLICY "owner vehicles" ON public.vehicles FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE POLICY "read drivers" ON public.drivers FOR SELECT TO authenticated USING (true);
CREATE POLICY "owner drivers" ON public.drivers FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE POLICY "read settings" ON public.settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "owner settings" ON public.settings FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

CREATE SEQUENCE public.task_code_seq;
GRANT USAGE ON SEQUENCE public.task_code_seq TO authenticated, service_role;

CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_code text NOT NULL UNIQUE DEFAULT ('MST-' || to_char(now(),'YYYY') || '-' || lpad(nextval('public.task_code_seq')::text, 5, '0')),
  title text NOT NULL,
  description text,
  assigned_to uuid REFERENCES public.employees(id),
  category text NOT NULL DEFAULT 'Other',
  priority text NOT NULL DEFAULT 'Normal',
  status text NOT NULL DEFAULT 'Not Started',
  assigned_date date NOT NULL DEFAULT current_date,
  due_date date,
  due_time time,
  vehicle_no text, driver_name text, customer_name text,
  loading_point text, unloading_point text, reference_no text,
  recurrence text NOT NULL DEFAULT 'None',
  recurrence_parent uuid REFERENCES public.tasks(id) ON DELETE SET NULL,
  cancel_reason text,
  completed_at timestamptz,
  completed_by uuid REFERENCES public.employees(id),
  last_update_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tasks_assigned_idx ON public.tasks(assigned_to);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO authenticated;
GRANT ALL ON public.tasks TO service_role;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owner all tasks" ON public.tasks FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE POLICY "staff read own tasks" ON public.tasks FOR SELECT TO authenticated USING (assigned_to = public.my_employee_id());
CREATE POLICY "staff update own tasks" ON public.tasks FOR UPDATE TO authenticated USING (assigned_to = public.my_employee_id()) WITH CHECK (assigned_to = public.my_employee_id());

CREATE TABLE public.task_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  author_id uuid REFERENCES public.employees(id),
  author_name text NOT NULL,
  comment text NOT NULL,
  status_at_time text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.task_comments TO authenticated;
GRANT ALL ON public.task_comments TO service_role;
ALTER TABLE public.task_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read comments" ON public.task_comments FOR SELECT TO authenticated USING (
  public.is_owner() OR EXISTS (SELECT 1 FROM public.tasks t WHERE t.id = task_id AND t.assigned_to = public.my_employee_id()));
CREATE POLICY "add comments" ON public.task_comments FOR INSERT TO authenticated WITH CHECK (
  author_id = public.my_employee_id() AND (public.is_owner() OR EXISTS (SELECT 1 FROM public.tasks t WHERE t.id = task_id AND t.assigned_to = public.my_employee_id())));

CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid REFERENCES public.tasks(id) ON DELETE SET NULL,
  task_code text,
  action text NOT NULL,
  details text,
  changed_by text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_log TO authenticated;
GRANT ALL ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read audit" ON public.audit_log FOR SELECT TO authenticated USING (
  public.is_owner() OR EXISTS (SELECT 1 FROM public.tasks t WHERE t.id = task_id AND t.assigned_to = public.my_employee_id()));

CREATE TABLE public.owner_todos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  notes text,
  due_date date,
  priority text NOT NULL DEFAULT 'Normal',
  done boolean NOT NULL DEFAULT false,
  done_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.owner_todos TO authenticated;
GRANT ALL ON public.owner_todos TO service_role;
ALTER TABLE public.owner_todos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owner todos" ON public.owner_todos FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

-- who am I (name) helper
CREATE OR REPLACE FUNCTION public.current_actor() RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE((SELECT name FROM public.employees WHERE user_id = auth.uid() LIMIT 1), 'System')
$$;

-- task guard + audit trigger
CREATE OR REPLACE FUNCTION public.tasks_before() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    -- staff may only change status
    IF NOT public.is_owner() AND auth.uid() IS NOT NULL THEN
      IF NEW.title IS DISTINCT FROM OLD.title OR NEW.assigned_to IS DISTINCT FROM OLD.assigned_to
        OR NEW.due_date IS DISTINCT FROM OLD.due_date OR NEW.priority IS DISTINCT FROM OLD.priority
        OR NEW.category IS DISTINCT FROM OLD.category THEN
        RAISE EXCEPTION 'Only the owner can change task details';
      END IF;
    END IF;
    IF NEW.status = 'Cancelled' AND OLD.status <> 'Cancelled' AND coalesce(trim(NEW.cancel_reason),'') = '' THEN
      RAISE EXCEPTION 'A reason is required to cancel a task';
    END IF;
    IF NEW.status = 'Completed' AND OLD.status <> 'Completed' THEN
      NEW.completed_at := now();
      NEW.completed_by := public.my_employee_id();
    ELSIF NEW.status <> 'Completed' THEN
      NEW.completed_at := NULL; NEW.completed_by := NULL;
    END IF;
    IF NEW.status IS DISTINCT FROM OLD.status THEN NEW.last_update_at := now(); END IF;
    NEW.updated_at := now();
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tasks_before_trg BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.tasks_before();

CREATE OR REPLACE FUNCTION public.tasks_audit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE actor text := public.current_actor(); n_old text; n_new text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT name INTO n_new FROM employees WHERE id = NEW.assigned_to;
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by)
      VALUES (NEW.id, NEW.task_code, 'Task created', 'Task ' || NEW.task_code || ' assigned by ' || actor || ' to ' || coalesce(n_new,'(unassigned)'), actor);
    RETURN NEW;
  END IF;
  IF NEW.assigned_to IS DISTINCT FROM OLD.assigned_to THEN
    SELECT name INTO n_old FROM employees WHERE id = OLD.assigned_to;
    SELECT name INTO n_new FROM employees WHERE id = NEW.assigned_to;
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by) VALUES (NEW.id, NEW.task_code, 'Reassigned', 'Reassigned from ' || coalesce(n_old,'-') || ' to ' || coalesce(n_new,'-'), actor);
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by) VALUES (NEW.id, NEW.task_code, 'Status changed', 'Status changed from ' || OLD.status || ' to ' || NEW.status || CASE WHEN NEW.status='Cancelled' THEN ' (reason: ' || coalesce(NEW.cancel_reason,'') || ')' ELSE '' END, actor);
  END IF;
  IF NEW.due_date IS DISTINCT FROM OLD.due_date THEN
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by) VALUES (NEW.id, NEW.task_code, 'Due date changed', 'Due date changed from ' || coalesce(to_char(OLD.due_date,'DD-MM-YYYY'),'-') || ' to ' || coalesce(to_char(NEW.due_date,'DD-MM-YYYY'),'-'), actor);
  END IF;
  IF NEW.priority IS DISTINCT FROM OLD.priority THEN
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by) VALUES (NEW.id, NEW.task_code, 'Priority changed', 'Priority changed from ' || OLD.priority || ' to ' || NEW.priority, actor);
  END IF;
  IF NEW.title IS DISTINCT FROM OLD.title OR NEW.description IS DISTINCT FROM OLD.description THEN
    INSERT INTO audit_log(task_id, task_code, action, details, changed_by) VALUES (NEW.id, NEW.task_code, 'Details edited', 'Title/description edited', actor);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tasks_audit_trg AFTER INSERT OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.tasks_audit();

CREATE OR REPLACE FUNCTION public.comment_after() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE tasks SET last_update_at = now() WHERE id = NEW.task_id;
  INSERT INTO audit_log(task_id, task_code, action, details, changed_by)
    SELECT NEW.task_id, t.task_code, 'Comment added', left(NEW.comment, 200), NEW.author_name FROM tasks t WHERE t.id = NEW.task_id;
  RETURN NEW;
END $$;
CREATE TRIGGER comment_after_trg AFTER INSERT ON public.task_comments FOR EACH ROW EXECUTE FUNCTION public.comment_after();

-- owner claims app (first signed-in user only)
CREATE OR REPLACE FUNCTION public.claim_owner(_name text, _email text) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF EXISTS (SELECT 1 FROM user_roles WHERE role = 'owner') THEN RETURN public.is_owner(); END IF;
  INSERT INTO user_roles(user_id, role) VALUES (auth.uid(), 'owner');
  UPDATE employees SET user_id = auth.uid(), email = _email WHERE is_owner AND user_id IS NULL;
  IF NOT FOUND THEN
    INSERT INTO employees(user_id, name, designation, department, email, is_owner) VALUES (auth.uid(), coalesce(_name,'Manish Sureka'), 'Owner', 'Management', _email, true);
  END IF;
  RETURN true;
END $$;
CREATE OR REPLACE FUNCTION public.owner_exists() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM user_roles WHERE role = 'owner')
$$;
GRANT EXECUTE ON FUNCTION public.owner_exists() TO anon, authenticated;

-- SAMPLE DATA
INSERT INTO public.employees(name, designation, department, mobile, is_owner) VALUES
('Manish Sureka','Owner','Management',NULL,true),
('Rajesh Kumar','Operations Manager','Operations','90000 00001',false),
('Amit Das','Fleet Manager','Fleet','90000 00002',false),
('Sunita Agarwal','Accounts Manager','Accounts','90000 00003',false),
('Prakash Singh','Billing Executive','Accounts','90000 00004',false),
('Rohit Jain','Tender Executive','Business Development','90000 00005',false),
('Debasish Ghosh','Compliance Officer','Compliance','90000 00006',false),
('Vikram Yadav','Driver Coordinator','Operations','90000 00007',false),
('Pooja Sharma','Customer Relations','Sales','90000 00008',false),
('Sanjay Mondal','Maintenance Supervisor','Workshop','90000 00009',false),
('Neha Gupta','GST & TDS Executive','Accounts','90000 00010',false);

INSERT INTO public.customers(name, contact_person, city) VALUES
('ABC Ltd.','Mr. Banerjee','Durgapur'),('IOCL Haldia','Terminal Office','Haldia'),('Bharat Petro Traders','Mr. Shah','Kolkata'),
('Eastern Chemicals Pvt Ltd','Ms. Roy','Asansol'),('ITC Ltd.','Logistics Desk','Kolkata'),('Steel Authority Depot','Stores','Bokaro');

INSERT INTO public.vehicles(vehicle_no, vehicle_type, insurance_expiry, fitness_expiry, pollution_expiry, permit_expiry) VALUES
('WB23F1234','Tanker 24KL', current_date + 12, current_date + 90, current_date + 40, current_date + 200),
('WB11G5678','Tanker 20KL', current_date + 150, current_date + 20, current_date + 5, current_date + 300),
('WB39C4321','Trailer', current_date + 60, current_date + 25, current_date + 120, current_date + 18),
('WB25H9090','Tanker 24KL', current_date - 2, current_date + 180, current_date + 60, current_date + 100),
('JH05K7777','Truck 10W', current_date + 220, current_date + 300, current_date + 28, current_date + 365);

INSERT INTO public.drivers(name, phone, license_no) VALUES
('Ramesh Paswan','90010 00001','WB-DL-001'),('Mohd. Salim','90010 00002','WB-DL-002'),('Gopal Mahato','90010 00003','WB-DL-003'),('Bablu Sardar','90010 00004','WB-DL-004');

WITH e AS (SELECT name, id FROM public.employees)
INSERT INTO public.tasks(title, description, assigned_to, category, priority, status, assigned_date, due_date, vehicle_no, driver_name, customer_name, loading_point, unloading_point, reference_no, last_update_at, completed_at)
SELECT v.title, v.descr, (SELECT id FROM e WHERE e.name = v.who), v.cat, v.pri, v.st, current_date - v.ago, current_date + v.due, v.veh, v.drv, v.cust, v.lp, v.up, v.ref,
  now() - (v.stale || ' days')::interval, CASE WHEN v.st = 'Completed' THEN now() - (v.stale || ' days')::interval END
FROM (VALUES
 ('Place tanker for Haldia loading','Place WB23F1234 at IOCL Haldia for HSD loading.','Rajesh Kumar','Vehicle Placement','High','In Progress',1,0,'WB23F1234','Ramesh Paswan','ABC Ltd.','IOCL Haldia','Durgapur','PO-2026-118',0),
 ('Follow up unloading at Durgapur','Vehicle reached customer, waiting for unloading slot.','Pooja Sharma','Unloading','Normal','Waiting for Customer',4,-1,'WB23F1234','Ramesh Paswan','ABC Ltd.','IOCL Haldia','Durgapur','LR ITC/2026/1234',3),
 ('Collect POD for WB23F1234','POD pending for LR ITC/2026/1234.','Rajesh Kumar','POD','High','Waiting for Documents',6,-3,'WB23F1234','Ramesh Paswan','ABC Ltd.',NULL,NULL,'ITC/2026/1234',4),
 ('Collect LR acknowledgement','LR ack for trip to Asansol.','Vikram Yadav','LR','Normal','Not Started',5,-2,'WB11G5678','Mohd. Salim','Eastern Chemicals Pvt Ltd',NULL,'Asansol','LR EC/0921',5),
 ('Prepare customer invoice - Sept trips','Freight invoice for 14 trips in September.','Prakash Singh','Billing','High','In Progress',3,1,NULL,NULL,'ITC Ltd.',NULL,NULL,'INV-DRAFT-09',1),
 ('Follow up outstanding payment ₹5,00,000','Invoice 1234 dated 01-09-2026 overdue since 01-10-2026.','Sunita Agarwal','Payment Collection','Critical','Waiting for Payment',7,-2,NULL,NULL,'ABC Ltd.',NULL,NULL,'INV 1234',3),
 ('Check vehicle insurance expiry','Insurance of WB23F1234 expires soon. Arrange renewal quote.','Debasish Ghosh','Insurance','Urgent','Not Started',2,3,'WB23F1234',NULL,NULL,NULL,NULL,NULL,2),
 ('Renew insurance WB25H9090','Insurance already expired - vehicle must not move.','Debasish Ghosh','Insurance','Critical','In Progress',3,-1,'WB25H9090',NULL,NULL,NULL,NULL,NULL,1),
 ('Check fitness certificate WB11G5678','Fitness due within 20 days.','Debasish Ghosh','Fitness','Normal','Not Started',1,7,'WB11G5678',NULL,NULL,NULL,NULL,NULL,1),
 ('Pollution certificate WB11G5678','PUC expiring in 5 days.','Amit Das','Pollution','High','Not Started',2,2,'WB11G5678',NULL,NULL,NULL,NULL,NULL,2),
 ('Permit renewal WB39C4321','National permit expiry in 18 days.','Debasish Ghosh','Permit','Normal','In Progress',4,6,'WB39C4321',NULL,NULL,NULL,NULL,NULL,3),
 ('Arrange driver for WB39C4321','Regular driver on leave; arrange relief driver.','Vikram Yadav','Driver','Urgent','Waiting for Driver',2,0,'WB39C4321',NULL,'Steel Authority Depot',NULL,'Bokaro',NULL,2),
 ('Follow up vehicle repair WB25H9090','Clutch overhaul at Dankuni workshop.','Sanjay Mondal','Vehicle Maintenance','High','Waiting for Vehicle',8,-4,'WB25H9090',NULL,NULL,NULL,NULL,'JOB-554',3),
 ('Tyre replacement JH05K7777','Two rear tyres worn out.','Sanjay Mondal','Tyre','Normal','Not Started',3,2,'JH05K7777',NULL,NULL,NULL,NULL,NULL,3),
 ('Reconcile FASTag - September','Match FASTag statement with trip sheets.','Sunita Agarwal','FASTag','Normal','In Progress',5,-1,NULL,NULL,NULL,NULL,NULL,'FT-SEP-26',2),
 ('Reconcile diesel consumption','Diesel vs km for all tankers, September.','Amit Das','Diesel','High','Not Started',6,-2,NULL,NULL,NULL,NULL,NULL,NULL,6),
 ('Submit quotation to Bharat Petro','Quotation for Kolkata-Haldia shuttle.','Rohit Jain','Customer Follow-up','High','In Progress',2,1,NULL,NULL,'Bharat Petro Traders',NULL,NULL,'Q-2026-044',1),
 ('Follow up IOCL tender','Technical bid status for IOCL bulk transport tender.','Rohit Jain','Tender','Urgent','Waiting',9,-3,NULL,NULL,'IOCL Haldia',NULL,NULL,'TENDER IOCL/BT/2026/07',4),
 ('Submit EMD for IOCL tender','EMD of ₹2,00,000 to be submitted by DD.','Rohit Jain','EMD','Critical','Not Started',1,1,NULL,NULL,'IOCL Haldia',NULL,NULL,'TENDER IOCL/BT/2026/07',1),
 ('Bank guarantee renewal','BG for ITC contract expires this month.','Sunita Agarwal','Bank Guarantee','High','Waiting',5,4,NULL,NULL,'ITC Ltd.',NULL,NULL,'BG-778812',5),
 ('Follow up security deposit refund','Refund of SD from Steel Authority Depot.','Pooja Sharma','Payment Collection','Normal','Waiting for Customer',12,-6,NULL,NULL,'Steel Authority Depot',NULL,NULL,'SD-2025-12',6),
 ('Check GST invoice - Eastern Chemicals','Verify GSTIN and HSN on invoice.','Neha Gupta','GST','Normal','Completed',3,-1,NULL,NULL,'Eastern Chemicals Pvt Ltd',NULL,NULL,'INV 1288',0),
 ('Follow up TDS certificate Q1','Form 16A pending from ABC Ltd.','Neha Gupta','TDS','Normal','Waiting for Documents',10,-5,NULL,NULL,'ABC Ltd.',NULL,NULL,'TDS-Q1',5),
 ('GSTR-1 data compilation','Compile outward supply data for GSTR-1.','Neha Gupta','GST','High','In Progress',2,5,NULL,NULL,NULL,NULL,NULL,NULL,1),
 ('Follow up transporter payment','Pay hired vehicle owner for 3 trips.','Sunita Agarwal','Accounts','Normal','Completed',4,-2,NULL,NULL,NULL,NULL,NULL,'HV-PAY-31',0),
 ('Collect freight bill from hired vehicle','Freight bill for JH05K7777 trip.','Prakash Singh','Billing','Low','Not Started',3,3,'JH05K7777',NULL,NULL,NULL,NULL,NULL,3),
 ('Accident claim follow-up WB39C4321','Minor accident at NH-19; surveyor report pending.','Debasish Ghosh','Accident / Claim','Urgent','Waiting for Documents',15,-8,'WB39C4321','Gopal Mahato',NULL,NULL,NULL,'CLAIM-NIA-5521',5),
 ('Bank reconciliation - HDFC current a/c','Reconcile September statement.','Sunita Agarwal','Banking','Normal','Completed',5,-1,NULL,NULL,NULL,NULL,NULL,NULL,1),
 ('Tanker placement Bokaro','Place JH05K7777 for steel scrap loading.','Rajesh Kumar','Loading','Normal','Completed',2,0,'JH05K7777','Bablu Sardar','Steel Authority Depot','Bokaro','Kolkata','PO-SAD-77',0),
 ('Collect PO from ITC for Oct trips','Monthly PO for October movements.','Pooja Sharma','Purchase Order','High','Not Started',1,2,NULL,NULL,'ITC Ltd.',NULL,NULL,NULL,1)
) AS v(title, descr, who, cat, pri, st, ago, due, veh, drv, cust, lp, up, ref, stale);

UPDATE public.tasks SET completed_by = assigned_to WHERE status = 'Completed';

INSERT INTO public.task_comments(task_id, author_id, author_name, comment, status_at_time, created_at)
SELECT t.id, t.assigned_to, e.name, c.txt, c.st, now() - (c.ago || ' days')::interval
FROM public.tasks t JOIN public.employees e ON e.id = t.assigned_to
JOIN (VALUES
 ('Place tanker for Haldia loading','Vehicle reached Haldia. Loading expected tomorrow morning.','In Progress',0),
 ('Follow up unloading at Durgapur','Vehicle loaded and dispatched.','In Progress',3),
 ('Follow up unloading at Durgapur','Vehicle reached customer. Waiting for unloading.','Waiting for Customer',3),
 ('Follow up outstanding payment ₹5,00,000','Spoke to accounts head; promised by Friday.','Waiting for Payment',3),
 ('Collect POD for WB23F1234','Driver says POD left at customer gate.','Waiting for Documents',4)
) AS c(title, txt, st, ago) ON c.title = t.title;

INSERT INTO public.owner_todos(title, due_date, priority) VALUES
('Call ABC Ltd. regarding new contract', current_date, 'High'),
('Review IOCL tender', current_date + 1, 'Critical'),
('Approve quotation for Bharat Petro', current_date, 'Normal'),
('Talk to bank regarding BG', current_date + 3, 'High'),
('Review monthly profitability', current_date + 5, 'Normal'),
('Approve vehicle purchase', current_date - 1, 'High'),
('Review outstanding debtors', current_date + 2, 'Normal');
