import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard, ListTodo, ListChecks, PlusCircle, Users, Truck, Building2, CalendarCheck,
  BarChart3, Sparkles, CheckCircle2, ScrollText, Settings, LogOut, Search, NotebookPen,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app")({
  ssr: false,
  component: AppLayout,
});

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/my-tasks", label: "My Tasks", icon: ListTodo },
  { to: "/tasks", label: "All Tasks", icon: ListChecks, owner: true },
  { to: "/tasks/new", label: "Add Task", icon: PlusCircle, owner: true },
  { to: "/my-todo", label: "My To-Do", icon: NotebookPen },
  { to: "/employees", label: "Employees", icon: Users, owner: true },
  { to: "/vehicles", label: "Vehicles", icon: Truck },
  { to: "/customers", label: "Customers", icon: Building2 },
  { to: "/summary", label: "Daily Summary", icon: CalendarCheck, owner: true },
  { to: "/reports", label: "Reports", icon: BarChart3, owner: true },
  { to: "/ai", label: "AI Assistant", icon: Sparkles, owner: true },
  { to: "/completed", label: "Completed Tasks", icon: CheckCircle2 },
  { to: "/audit", label: "Audit Trail", icon: ScrollText, owner: true },
  { to: "/settings", label: "Settings", icon: Settings, owner: true },
] as const;

function AppLayout() {
  const { loading, session, me, isOwner } = useSession();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/", replace: true });
  }, [loading, session, navigate]);

  if (loading || !session) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  }

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  };

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="border-b border-sidebar-border px-5 py-5">
          <div className="font-display text-xl font-bold leading-tight text-sidebar-accent-foreground">MANISH SUREKA</div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-sidebar-primary">Transport To-Do</div>
        </div>
        <nav className="flex-1 overflow-y-auto px-2 py-3">
          {NAV.filter((n) => !("owner" in n) || isOwner).map((n) => {
            const active = path === n.to || (n.to !== "/tasks" && path.startsWith(n.to + "/")) || (n.to === "/tasks" && path === "/tasks");
            return (
              <Link key={n.to} to={n.to}
                className={cn("mb-0.5 flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  active ? "bg-sidebar-primary text-sidebar-primary-foreground" : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground")}>
                <n.icon className="h-4 w-4" />{n.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <div className="px-2 pb-2 text-xs">
            <div className="font-semibold text-sidebar-accent-foreground">{me?.name ?? session.user.email}</div>
            <div className="opacity-70">{isOwner ? "Owner / Admin" : me?.designation}</div>
          </div>
          <button onClick={signOut} className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
            <LogOut className="h-4 w-4" />Logout
          </button>
        </div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-10 flex items-center gap-3 border-b bg-card/95 px-6 py-3 backdrop-blur">
          <form className="relative w-full max-w-md" onSubmit={(e) => { e.preventDefault(); navigate({ to: "/search", search: { q } }); }}>
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search everything — WB23F1234, LR, invoice, customer, comment…" className="pl-9" />
          </form>
          <div className="ml-auto text-xs text-muted-foreground">
            {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
          </div>
          <button onClick={signOut} className="md:hidden"><LogOut className="h-4 w-4" /></button>
        </header>
        <nav className="flex gap-1 overflow-x-auto border-b bg-card px-3 py-2 md:hidden">
          {NAV.filter((n) => !("owner" in n) || isOwner).map((n) => (
            <Link key={n.to} to={n.to} className="whitespace-nowrap rounded px-2 py-1 text-xs font-medium text-muted-foreground" activeProps={{ className: "bg-accent text-accent-foreground" }}>{n.label}</Link>
          ))}
        </nav>
        <main className="flex-1 p-6"><Outlet /></main>
      </div>
    </div>
  );
}

