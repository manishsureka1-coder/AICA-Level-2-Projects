import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

async function all<T>(q: PromiseLike<{ data: T[] | null; error: { message: string } | null }>) {
  const { data, error } = await q;
  if (error) throw new Error(error.message);
  return data ?? [];
}

export const useTasks = () =>
  useQuery({
    queryKey: ["tasks"],
    queryFn: () => all(supabase.from("tasks").select("*").order("created_at", { ascending: false }).limit(5000)),
  });
export const useEmployees = () =>
  useQuery({ queryKey: ["employees"], queryFn: () => all(supabase.from("employees").select("*").order("name")) });
export const useVehicles = () =>
  useQuery({ queryKey: ["vehicles"], queryFn: () => all(supabase.from("vehicles").select("*").order("vehicle_no")) });
export const useCustomers = () =>
  useQuery({ queryKey: ["customers"], queryFn: () => all(supabase.from("customers").select("*").order("name")) });
export const useDrivers = () =>
  useQuery({ queryKey: ["drivers"], queryFn: () => all(supabase.from("drivers").select("*").order("name")) });
export const useComments = (taskId?: string) =>
  useQuery({
    queryKey: ["comments", taskId ?? "all"],
    queryFn: () => {
      const q = supabase.from("task_comments").select("*").order("created_at", { ascending: true }).limit(5000);
      return all(taskId ? q.eq("task_id", taskId) : q);
    },
  });
export const useAudit = (taskId?: string) =>
  useQuery({
    queryKey: ["audit", taskId ?? "all"],
    queryFn: () => {
      const q = supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(2000);
      return all(taskId ? q.eq("task_id", taskId) : q);
    },
  });
export const useTodos = () =>
  useQuery({ queryKey: ["todos"], queryFn: () => all(supabase.from("owner_todos").select("*").order("due_date")) });

export const useInvalidate = () => {
  const qc = useQueryClient();
  return (...keys: string[]) => Promise.all(keys.map((k) => qc.invalidateQueries({ queryKey: [k] })));
};

export const employeeMap = (emps: { id: string; name: string }[]) =>
  Object.fromEntries(emps.map((e) => [e.id, e.name])) as Record<string, string>;
