<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Staff are rows in `employees`, optionally linked to an auth user; tasks reference employees so data can exist before logins. Why: owner creates staff first, logins later.
- Audit trail, completion stamps, recurrence and staff-edit restrictions live in database triggers. Why: controls cannot be bypassed from the browser.
- Overdue, escalated, carried-forward and stale states are derived on read in `src/lib/task-utils.ts`, never stored. Why: no scheduled jobs needed.
- First signed-in user claims the owner role via `claim_owner()`; staff logins are created by owner-only server functions. Why: no self-signup for staff.
