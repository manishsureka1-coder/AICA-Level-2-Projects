import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { FileSpreadsheet, FileText } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useSession } from "@/hooks/use-session";
import { useComments, useEmployees, useTasks } from "@/lib/data";
import { exportExcel, exportPdf, type Sheet } from "@/lib/exports";
import { type Task, daysPending, fmtDate, isOpen, isOverdue, todayISO, addDaysISO } from "@/lib/task-utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/reports")({
  head: () => ({ meta: [{ title: "Reports & Analytics — MS Transport To-Do" }, { name: "description", content: "Task reports, performance analytics and exports." }, { property: "og:title", content: "Reports" }, { property: "og:description", content: "Reports and analytics." }] }),
  component: Reports,
});

const hrs = (t: Task) => t.completed_at ? (new Date(t.completed_at).getTime() - new Date(t.assigned_date + "T00:00:00").getTime()) / 86400000 : 0;
const avg = (a: number[]) => (a.length ? Math.round((a.reduce((x, y) => x + y, 0) / a.length) * 10) / 10 : 0);

function groupCount(tasks: Task[], key: (t: Task) => string | null | undefined): Sheet["rows"] {
  const m: Record<string, { open: number; overdue: number; done: number }> = {};
  tasks.forEach((t) => {
    const k = key(t) || "—";
    m[k] ??= { open: 0, overdue: 0, done: 0 };
    if (isOpen(t)) m[k].open++;
    if (isOverdue(t)) m[k].overdue++;
    if (t.status === "Completed") m[k].done++;
  });
  return Object.entries(m).sort((a, b) => b[1].open - a[1].open).map(([k, v]) => [k, v.open, v.overdue, v.done]);
}

function Reports() {
  const { isOwner } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  const { data: comments = [] } = useComments();
  const [from, setFrom] = useState(addDaysISO(todayISO(), -30));
  const [to, setTo] = useState(todayISO());
  const [active, setActive] = useState("Employee-wise pending");
  const name = (id: string | null) => emps.find((e) => e.id === id)?.name ?? "—";
  const staff = emps.filter((e) => !e.is_owner);

  const perf = useMemo(() => staff.map((e) => {
    const mine = tasks.filter((t) => t.assigned_to === e.id);
    const done = mine.filter((t) => t.status === "Completed");
    const commented = new Set(comments.map((c) => c.task_id));
    return {
      name: e.name, assigned: mine.length, completed: done.length, pending: mine.filter(isOpen).length, overdue: mine.filter(isOverdue).length,
      avgDays: avg(done.map(hrs)),
      onTime: done.filter((t) => !t.due_date || (t.completed_at ?? "").slice(0, 10) <= t.due_date).length,
      late: done.filter((t) => t.due_date && t.completed_at!.slice(0, 10) > t.due_date).length,
      noUpdates: mine.filter((t) => isOpen(t) && !commented.has(t.id)).length,
    };
  }), [tasks, emps, comments]); // eslint-disable-line react-hooks/exhaustive-deps

  const taskRow = (t: Task) => [t.task_code, t.title, name(t.assigned_to), t.category, t.priority, t.status, fmtDate(t.assigned_date), fmtDate(t.due_date), daysPending(t)];
  const taskCols = ["Task ID", "Title", "Assigned to", "Category", "Priority", "Status", "Assigned", "Due", "Days"];
  const gc = (label: string) => [label, "Open", "Overdue", "Completed"];
  const done = tasks.filter((t) => t.status === "Completed");
  const inRange = done.filter((t) => t.completed_at!.slice(0, 10) >= from && t.completed_at!.slice(0, 10) <= to);

  const daily: Record<string, number> = {};
  for (let i = 13; i >= 0; i--) daily[addDaysISO(todayISO(), -i)] = 0;
  done.forEach((t) => { const d = t.completed_at!.slice(0, 10); if (d in daily) daily[d] = (daily[d] ?? 0) + 1; });
  const monthly: Record<string, number> = {};
  done.forEach((t) => { const m = t.completed_at!.slice(0, 7); monthly[m] = (monthly[m] ?? 0) + 1; });

  const reports: Record<string, Sheet> = {
    "Employee-wise pending": { name: "Pending", columns: gc("Employee"), rows: groupCount(tasks, (t) => name(t.assigned_to)) },
    "Employee-wise completed": { name: "Completed", columns: ["Employee", "Completed", "Avg days", "On time", "Late"], rows: perf.map((p) => [p.name, p.completed, p.avgDays, p.onTime, p.late]) },
    "Overdue tasks": { name: "Overdue", columns: taskCols, rows: tasks.filter(isOverdue).map(taskRow) },
    "Customer-wise": { name: "Customer", columns: gc("Customer"), rows: groupCount(tasks, (t) => t.customer_name) },
    "Vehicle-wise": { name: "Vehicle", columns: gc("Vehicle"), rows: groupCount(tasks, (t) => t.vehicle_no) },
    "Category-wise": { name: "Category", columns: gc("Category"), rows: groupCount(tasks, (t) => t.category) },
    "Priority-wise": { name: "Priority", columns: gc("Priority"), rows: groupCount(tasks, (t) => t.priority) },
    "Completed between dates": { name: "Completed range", columns: [...taskCols, "Completed on"], rows: inRange.map((t) => [...taskRow(t), fmtDate(t.completed_at)]) },
    "Average completion time": { name: "Avg time", columns: ["Employee", "Completed", "Average days"], rows: perf.map((p) => [p.name, p.completed, p.avgDays]) },
    "Longest pending": { name: "Longest", columns: taskCols, rows: [...tasks.filter(isOpen)].sort((a, b) => daysPending(b) - daysPending(a)).slice(0, 25).map(taskRow) },
    "Daily completion": { name: "Daily", columns: ["Date", "Completed"], rows: Object.entries(daily).map(([d, n]) => [fmtDate(d), n]) },
    "Monthly completion": { name: "Monthly", columns: ["Month", "Completed"], rows: Object.entries(monthly).sort().map(([m, n]) => [m, n]) },
    "Employee performance": { name: "Performance", columns: ["Employee", "Assigned", "Completed", "Pending", "Overdue", "Avg days", "Before due", "After due", "No daily updates"], rows: perf.map((p) => [p.name, p.assigned, p.completed, p.pending, p.overdue, p.avgDays, p.onTime, p.late, p.noUpdates]) },
  };
  if (!isOwner) return <OwnerOnly />;
  const r = reports[active] ?? reports["Employee-wise pending"]!;
  const fname = active.toLowerCase().replace(/[^a-z0-9]+/g, "_");

  return (
    <>
      <PageHeader title="Reports & Analytics" subtitle="Every report can be downloaded as Excel or PDF." />
      <div className="mb-6 grid gap-6 xl:grid-cols-2">
        <div className="card-surface p-4">
          <div className="mb-2 font-display text-lg font-bold uppercase">Employee workload</div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={perf}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} angle={-20} textAnchor="end" height={50} /><YAxis allowDecimals={false} /><Tooltip /><Legend />
              <Bar dataKey="pending" name="Pending" fill="var(--chart-1)" /><Bar dataKey="overdue" name="Overdue" fill="var(--chart-4)" /><Bar dataKey="completed" name="Completed" fill="var(--chart-3)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card-surface p-4">
          <div className="mb-2 font-display text-lg font-bold uppercase">Daily completions (14 days)</div>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={Object.entries(daily).map(([d, n]) => ({ d: d.slice(8) + "/" + d.slice(5, 7), n }))}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="d" tick={{ fontSize: 10 }} /><YAxis allowDecimals={false} /><Tooltip /><Line dataKey="n" name="Completed" stroke="var(--chart-2)" strokeWidth={3} /></LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        <div className="card-surface h-fit p-2">
          {Object.keys(reports).map((k) => (
            <button key={k} onClick={() => setActive(k)} className={cn("block w-full rounded px-3 py-2 text-left text-sm", active === k ? "bg-primary text-primary-foreground" : "hover:bg-muted")}>{k}</button>
          ))}
        </div>
        <div className="card-surface overflow-hidden">
          <div className="flex flex-wrap items-center gap-2 border-b p-3">
            <div className="font-display text-lg font-bold uppercase">{active}</div>
            {active === "Completed between dates" && (<><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-8 w-36" /><span>to</span><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-8 w-36" /></>)}
            <div className="ml-auto flex gap-2">
              <Button size="sm" variant="outline" onClick={() => exportExcel(`${fname}.xlsx`, [r])}><FileSpreadsheet className="mr-1 h-4 w-4" />Excel</Button>
              <Button size="sm" variant="outline" onClick={() => exportPdf(`${fname}.pdf`, active, r)}><FileText className="mr-1 h-4 w-4" />PDF</Button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground"><tr>{r.columns.map((c) => <th key={c} className="px-3 py-2">{c}</th>)}</tr></thead>
              <tbody>{r.rows.map((row, i) => <tr key={i} className="border-t">{row.map((c, j) => <td key={j} className="px-3 py-2">{c}</td>)}</tr>)}
                {r.rows.length === 0 && <tr><td className="px-3 py-8 text-center text-muted-foreground" colSpan={r.columns.length}>No data.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
