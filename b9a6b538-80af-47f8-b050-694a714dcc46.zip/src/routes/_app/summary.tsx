import { createFileRoute, Link } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { PriorityBadge, StatusBadge, Pill } from "@/components/badges";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";
import { ruleInsights } from "@/lib/insights";
import { attentionScore, completedToday, daysOverdue, daysPending, isCritical, isDueToday, isEscalated, isOpen, isOverdue, isStale } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/summary")({
  head: () => ({ meta: [{ title: "Today's Management Summary — MS Transport To-Do" }, { name: "description", content: "Daily owner summary with attention list." }, { property: "og:title", content: "Daily Summary" }, { property: "og:description", content: "Daily management summary." }] }),
  component: Summary,
});

function Summary() {
  const { isOwner } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  if (!isOwner) return <OwnerOnly />;
  const names = employeeMap(emps);
  const open = tasks.filter(isOpen);
  const stats = [
    ["Total pending", open.length], ["Due today", open.filter(isDueToday).length], ["Overdue", open.filter(isOverdue).length],
    ["Critical", open.filter(isCritical).length], ["Completed today", tasks.filter(completedToday).length], ["No update > 2 days", open.filter(isStale).length],
  ] as const;
  const attention = [...open].sort((a, b) => attentionScore(b) - attentionScore(a)).slice(0, 15);
  return (
    <>
      <PageHeader title="Today's Management Summary" subtitle={`Date: ${new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })}`}>
        <Button variant="outline" onClick={() => window.print()}><Printer className="mr-1 h-4 w-4" />Print</Button>
      </PageHeader>
      <div className="card-surface mb-6 grid grid-cols-2 divide-x divide-y md:grid-cols-6 md:divide-y-0">
        {stats.map(([k, v]) => (
          <div key={k} className="p-4"><div className="font-display text-4xl font-bold">{v}</div><div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{k}</div></div>
        ))}
      </div>
      <h2 className="mb-3 text-xl font-bold uppercase">Attention required</h2>
      <div className="card-surface mb-6 overflow-x-auto">
        <table className="w-full text-sm">
          <tbody>
            {attention.map((t, i) => (
              <tr key={t.id} className="border-t first:border-t-0">
                <td className="w-8 px-4 py-2 font-mono text-muted-foreground">{i + 1}</td>
                <td className="px-3 py-2"><Link to="/tasks/$id" params={{ id: t.id }} className="font-semibold hover:underline">{t.title}</Link><div className="text-xs text-muted-foreground">{t.task_code} · {names[t.assigned_to ?? ""]}</div></td>
                <td className="px-3 py-2"><PriorityBadge priority={t.priority} /></td>
                <td className="px-3 py-2"><StatusBadge status={t.status} /></td>
                <td className="px-3 py-2 whitespace-nowrap">{isEscalated(t) && <Pill tone="solidDanger">Escalated</Pill>} {isOverdue(t) ? `${daysOverdue(t)}d overdue` : `${daysPending(t)}d pending`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h2 className="mb-3 text-xl font-bold uppercase">Observations</h2>
      <ul className="card-surface list-disc space-y-1 py-4 pl-10 pr-4 text-sm">
        {ruleInsights(tasks, emps).map((i, k) => <li key={k}>{i.text}</li>)}
      </ul>
    </>
  );
}
