import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { Input } from "@/components/ui/input";
import { useSession } from "@/hooks/use-session";
import { useAudit } from "@/lib/data";
import { fmtDateTime } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/audit")({
  head: () => ({ meta: [{ title: "Audit Trail — MS Transport To-Do" }, { name: "description", content: "Tamper-proof record of every change." }, { property: "og:title", content: "Audit Trail" }, { property: "og:description", content: "Audit trail." }] }),
  component: Audit,
});

function Audit() {
  const { isOwner } = useSession();
  const { data: rows = [] } = useAudit();
  const [q, setQ] = useState("");
  if (!isOwner) return <OwnerOnly />;
  const f = rows.filter((r) => [r.task_code, r.action, r.details, r.changed_by].join(" ").toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <PageHeader title="Audit Trail" subtitle="Recorded automatically by the database. Nobody can edit or delete entries.">
        <Input placeholder="Filter…" value={q} onChange={(e) => setQ(e.target.value)} className="w-64" />
      </PageHeader>
      <div className="card-surface overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr><th className="px-4 py-2">When</th><th className="px-3 py-2">Task</th><th className="px-3 py-2">Action</th><th className="px-3 py-2">Details</th><th className="px-3 py-2">Changed by</th></tr>
          </thead>
          <tbody>
            {f.map((r) => (
              <tr key={r.id} className="border-t">
                <td className="px-4 py-2 whitespace-nowrap">{fmtDateTime(r.created_at)}</td>
                <td className="px-3 py-2 font-mono text-xs">{r.task_id ? <Link to="/tasks/$id" params={{ id: r.task_id }} className="text-primary hover:underline">{r.task_code}</Link> : "—"}</td>
                <td className="px-3 py-2 font-semibold">{r.action}</td><td className="px-3 py-2">{r.details}</td><td className="px-3 py-2">{r.changed_by}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
