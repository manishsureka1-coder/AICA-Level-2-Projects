import { cva } from "class-variance-authority";
import { cn } from "@/lib/utils";

const pill = cva("inline-flex items-center whitespace-nowrap rounded px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide", {
  variants: {
    tone: {
      neutral: "bg-muted text-muted-foreground",
      info: "bg-info/15 text-info",
      warning: "bg-warning/25 text-warning-foreground",
      success: "bg-success/15 text-success",
      danger: "bg-destructive/15 text-destructive",
      solidDanger: "bg-destructive text-destructive-foreground",
      primary: "bg-primary text-primary-foreground",
      accent: "bg-accent text-accent-foreground",
    },
  },
  defaultVariants: { tone: "neutral" },
});
type Tone = "neutral" | "info" | "warning" | "success" | "danger" | "solidDanger" | "primary" | "accent";

export function Pill({ tone, children, className }: { tone?: Tone; children: React.ReactNode; className?: string }) {
  return <span className={cn(pill({ tone }), className)}>{children}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const tone: Tone =
    status === "Completed" ? "success" :
    status === "Cancelled" ? "neutral" :
    status === "In Progress" ? "info" :
    status === "Not Started" ? "primary" : "warning";
  return <Pill tone={tone}>{status}</Pill>;
}

export function PriorityBadge({ priority }: { priority: string }) {
  const tone: Tone =
    priority === "Critical" ? "solidDanger" :
    priority === "Urgent" ? "danger" :
    priority === "High" ? "accent" :
    priority === "Low" ? "neutral" : "info";
  return <Pill tone={tone}>{priority}</Pill>;
}
