import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { AlertTriangle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PriorityBadge, StatusBadge, Pill } from "@/components/badges";
import { CATEGORIES, PRIORITIES, STATUSES } from "@/lib/constants";
import {
  type Task, daysPending, fmtDate, isCarriedForward, isDueToday, isEscalated, isOpen, isOverdue,
  isStale, searchText, todayISO,
} from "@/lib/task-utils";
import { cn } from "@/lib/utils";

const VIEWS = ["Pending", "Today", "Overdue", "Completed", "All"] as const;

export function TaskTable({
  tasks, names, defaultView = "Pending", showAssignee = true, initialQuery = "", hideViews = false,
}: {
  tasks: Task[]; names: Record<string, string>; defaultView?: (typeof VIEWS)[number];
  showAssignee?: boolean; initialQuery?: string; hideViews?: boolean;
}) {
  const [view, setView] = useState<(typeof VIEWS)[number]>(defaultView);
  const [q, setQ] = useState(initialQuery);
  const [cat, setCat] = useState("all");
  const [pri, setPri] = useState("all");
  const [st, setSt] = useState("all");
  const [date, setDate] = useState("");
  const [cust, setCust] = useState("");
  const [veh, setVeh] = useState("");

  const rows = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return tasks
      .filter((t) => {
        if (view === "Pending" && !isOpen(t)) return false;
        if (view === "Today" && !(isDueToday(t) || (t.completed_at?.slice(0, 10) === todayISO()))) return false;
        if (view === "Overdue" && !isOverdue(t)) return false;
        if (view === "Completed" && t.status !== "Completed") return false;
        if (cat !== "all" && t.category !== cat) return false;
        if (pri !== "all" && t.priority !== pri) return false;
        if (st !== "all" && t.status !== st) return false;
        if (date && t.due_date !== date && t.assigned_date !== date) return false;
        if (cust && !(t.customer_name ?? "").toLowerCase().includes(cust.toLowerCase())) return false;
        if (veh && !(t.vehicle_no ?? "").toLowerCase().includes(veh.toLowerCase())) return false;
        if (ql && !searchText(t, names[t.assigned_to ?? ""]).includes(ql)) return false;
        return true;
      })
      .sort((a, b) => (a.due_date ?? "9999").localeCompare(b.due_date ?? "9999"));
  }, [tasks, view, q, cat, pri, st, date, cust, veh, names]);

  return (
    <div className="card-surface overflow-hidden">
      <div className="flex flex-wrap items-center gap-2 border-b p-3">
        {!hideViews && (
          <div className="flex rounded-md bg-muted p-0.5">
            {VIEWS.map((v) => (
              <button key={v} onClick={() => setView(v)}
                className={cn("rounded px-3 py-1.5 text-xs font-semibold", view === v ? "bg-card text-foreground shadow-sm" : "text-muted-foreground")}>
                {v}
              </button>
            ))}
          </div>
        )}
        <Input placeholder="Search task, vehicle, LR, invoice…" value={q} onChange={(e) => setQ(e.target.value)} className="h-9 w-56" />
        <Input placeholder="Customer" value={cust} onChange={(e) => setCust(e.target.value)} className="h-9 w-32" />
        <Input placeholder="Vehicle" value={veh} onChange={(e) => setVeh(e.target.value)} className="h-9 w-28" />
        <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-9 w-36" />
        <F value={cat} onChange={setCat} label="Category" items={CATEGORIES} />
        <F value={pri} onChange={setPri} label="Priority" items={PRIORITIES} />
        <F value={st} onChange={setSt} label="Status" items={STATUSES} />
        <span className="ml-auto text-xs text-muted-foreground">{rows.length} tasks</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-3 py-2">Task</th>
              {showAssignee && <th className="px-3 py-2">Assigned to</th>}
              <th className="px-3 py-2">Category</th>
              <th className="px-3 py-2">Priority</th>
              <th className="px-3 py-2">Status</th>
              <th className="px-3 py-2">Assigned</th>
              <th className="px-3 py-2">Due</th>
              <th className="px-3 py-2">Pending</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id} className={cn("border-t align-top hover:bg-muted/40", isOverdue(t) && "row-overdue")}>
                <td className="px-3 py-2">
                  <Link to="/tasks/$id" params={{ id: t.id }} className="font-medium text-foreground hover:underline">{t.title}</Link>
                  <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="font-mono">{t.task_code}</span>
                    {t.vehicle_no && <span>· {t.vehicle_no}</span>}
                    {t.customer_name && <span>· {t.customer_name}</span>}
                    {isEscalated(t) && <Pill tone="solidDanger"><AlertTriangle className="mr-1 h-3 w-3" />Escalated</Pill>}
                    {isCarriedForward(t) && <Pill tone="neutral">Carried fwd</Pill>}
                    {isStale(t) && <Pill tone="warning">No update 2d+</Pill>}
                    {t.recurrence !== "None" && <Pill tone="info">{t.recurrence}</Pill>}
                  </div>
                </td>
                {showAssignee && <td className="px-3 py-2 whitespace-nowrap">{names[t.assigned_to ?? ""] ?? "—"}</td>}
                <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">{t.category}</td>
                <td className="px-3 py-2"><PriorityBadge priority={t.priority} /></td>
                <td className="px-3 py-2"><StatusBadge status={t.status} /></td>
                <td className="px-3 py-2 whitespace-nowrap">{fmtDate(t.assigned_date)}</td>
                <td className={cn("px-3 py-2 whitespace-nowrap", isOverdue(t) && "font-semibold text-destructive")}>{fmtDate(t.due_date)}</td>
                <td className="px-3 py-2 whitespace-nowrap">{isOpen(t) ? `${daysPending(t)} days` : fmtDate(t.completed_at)}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={8} className="px-3 py-10 text-center text-muted-foreground">No tasks match these filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function F({ value, onChange, label, items }: { value: string; onChange: (v: string) => void; label: string; items: readonly string[] }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="h-9 w-36"><SelectValue placeholder={label} /></SelectTrigger>
      <SelectContent>
        <SelectItem value="all">All {label.toLowerCase()}</SelectItem>
        {items.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}
