export type Sheet = { name: string; columns: string[]; rows: (string | number | null | undefined)[][] };

export async function exportExcel(filename: string, sheets: Sheet[]) {
  const XLSX = await import("xlsx");
  const wb = XLSX.utils.book_new();
  sheets.forEach((s) => {
    const ws = XLSX.utils.aoa_to_sheet([s.columns, ...s.rows]);
    XLSX.utils.book_append_sheet(wb, ws, s.name.slice(0, 31));
  });
  XLSX.writeFile(wb, filename);
}

export async function exportPdf(filename: string, title: string, sheet: Sheet) {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const doc = new jsPDF({ orientation: "landscape" });
  doc.setFontSize(14);
  doc.text("MANISH SUREKA TRANSPORT TO-DO", 14, 14);
  doc.setFontSize(11);
  doc.text(`${title} — ${new Date().toLocaleDateString("en-IN")}`, 14, 21);
  autoTable(doc, {
    startY: 26, head: [sheet.columns],
    body: sheet.rows.map((r) => r.map((c) => (c == null ? "" : String(c).replace("₹", "Rs.")))),
    styles: { fontSize: 8 }, headStyles: { fillColor: [30, 45, 80] },
  });
  doc.save(filename);
}
