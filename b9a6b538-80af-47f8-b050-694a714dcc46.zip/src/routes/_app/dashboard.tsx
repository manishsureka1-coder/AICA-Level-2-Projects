import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ListTodo, CalendarClock, AlarmClock, CheckCircle2, Flame, Siren, Repeat, UserRound, FileWarning, IndianRupee, Plus, AlertTriangle,
} from "lucide-react";
import { PageHeader } from "@/components/page";
import { StatCard } from "@/components/stat-card";
import { Button } from "@/components/ui/button";
import { PriorityBadge, StatusBadge } from "@/components/badges";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks, useVehicles } from "@/lib/data";
import {
  completedToday, daysOverdue, fmtDate, isCarriedForward, isCritical, isDueToday, isDueTomorrow,
  isEscalated, isOpen, isOverdue, isStale, todayISO, addDaysISO,
} from "@/lib/task-utils";
import { MyTasksView } from "./my-tasks";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — MS Transport To-Do" }, { name: "description", content: "Owner dashboard of open, overdue and critical tasks." }, { property: "og:title", content: "Dashboard — MS Transport To-Do" }, { property: "og:description", content: "Owner dashboard." }] }),
  component: Dashboard,
});

function Dashboard() {
  const { isOwner } = useSession();
  if (!isOwner) return <MyTasksView />;
  return <OwnerDashboard />;
}

function OwnerDashboard() {
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  const { data: vehicles = [] } = useVehicles();
  const names = employeeMap(emps);
  const open = tasks.filter(isOpen);
  const criticalOverdue = open.filter((t) => isOverdue(t) && t.priority === "Critical");
  const escalated = open.filter(isEscalated);
  const in30 = addDaysISO(todayISO(), 30);
  const docAlerts = vehicles.flatMap((v) =>
    (["insurance_expiry", "fitness_expiry", "pollution_expiry", "permit_expiry"] as const)
      .filter((k) => v[k] && v[k]! <= in30)
      .map((k) => ({ v: v.vehicle_no, doc: k.replace("_expiry", ""), date: v[k]!, expired: v[k]! < todayISO() })),
  );

  const cards = [
    { label: "Total open tasks", value: open.length, icon: ListTodo },
    { label: "Due today", value: open.filter(isDueToday).length, icon: CalendarClock, tone: "accent" as const },
    { label: "Overdue", value: open.filter(isOverdue).length, icon: AlarmClock, tone: "danger" as const },
    { label: "Completed today", value: tasks.filter(completedToday).length, icon: CheckCircle2, tone: "success" as const },
    { label: "High priority", value: open.filter((t) => ["High", "Urgent"].includes(t.priority)).length, icon: Flame, tone: "warning" as const },
    { label: "Critical", value: open.filter(isCritical).length, icon: Siren, tone: "danger" as const },
    { label: "Carried forward", value: open.filter(isCarriedForward).length, icon: Repeat },
    { label: "Waiting for customer", value: open.filter((t) => t.status === "Waiting for Customer").length, icon: UserRound, tone: "warning" as const },
    { label: "Waiting for documents", value: open.filter((t) => t.status === "Waiting for Documents").length, icon: FileWarning, tone: "warning" as const },
    { label: "Waiting for payment", value: open.filter((t) => t.status === "Waiting for Payment").length, icon: IndianRupee, tone: "warning" as const },
  ];

  const staff = emps.filter((e) => !e.is_owner && e.active);
  const alerts = [
    ...open.filter(isDueToday).map((t) => ({ t, msg: "Due today" })),
    ...open.filter(isDueTomorrow).map((t) => ({ t, msg: "Due tomorrow" })),
    ...open.filter((t) => isStale(t) && !isOverdue(t)).map((t) => ({ t, msg: "No update for 2+ days" })),
  ].slice(0, 12);

  return (
    <>
      <PageHeader title="Owner Dashboard" subtitle="Who has to do what, by when — and what needs your attention.">
        <Button asChild variant="default" className="bg-accent text-accent-foreground hover:bg-accent/90">
          <Link to="/tasks/new"><Plus className="mr-1 h-4 w-4" />Add new task</Link>
        </Button>
      </PageHeader>

      {criticalOverdue.length > 0 && (
        <div className="mb-6 rounded-lg border-2 border-destructive bg-destructive/10 p-4">
          <div className="mb-2 flex items-center gap-2 font-display text-lg font-bold uppercase text-destructive">
            <Siren className="h-5 w-5" /> Critical tasks overdue — {criticalOverdue.length}
          </div>
          <ul className="space-y-1 text-sm">
            {criticalOverdue.map((t) => (
              <li key={t.id}>
                <Link to="/tasks/$id" params={{ id: t.id }} className="font-semibold hover:underline">{t.title}</Link>
                <span className="text-muted-foreground"> — {names[t.assigned_to ?? ""]} · overdue {daysOverdue(t)} day(s)</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        {cards.map((c) => <StatCard key={c.label} {...c} />)}
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <div className="card-surface overflow-hidden xl:col-span-2">
          <div className="border-b px-4 py-3 font-display text-lg font-bold uppercase">Managers & staff</div>
          <table className="w-full text-sm">
            <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr><th className="px-4 py-2">Employee</th><th className="px-3 py-2 text-right">Open</th><th className="px-3 py-2 text-right">Overdue</th><th className="px-3 py-2 text-right">Completed today</th><th className="px-3 py-2 text-right">Critical</th><th className="px-3 py-2 text-right">Escalated</th></tr>
            </thead>
            <tbody>
              {staff.map((e) => {
                const mine = tasks.filter((t) => t.assigned_to === e.id);
                const mo = mine.filter(isOpen);
                const od = mo.filter(isOverdue).length;
                return (
                  <tr key={e.id} className="border-t hover:bg-muted/40">
                    <td className="px-4 py-2">
                      <Link to="/employees/$id" params={{ id: e.id }} className="font-semibold text-primary hover:underline">{e.name}</Link>
                      <div className="text-xs text-muted-foreground">{e.designation} · {e.department}</div>
                    </td>
                    <td className="px-3 py-2 text-right font-mono">{mo.length}</td>
                    <td className={`px-3 py-2 text-right font-mono ${od ? "font-bold text-destructive" : ""}`}>{od}</td>
                    <td className="px-3 py-2 text-right font-mono">{mine.filter(completedToday).length}</td>
                    <td className="px-3 py-2 text-right font-mono">{mo.filter(isCritical).length}</td>
                    <td className="px-3 py-2 text-right font-mono">{mo.filter(isEscalated).length}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="space-y-6">
          <div className="card-surface">
            <div className="flex items-center gap-2 border-b px-4 py-3 font-display text-lg font-bold uppercase"><AlertTriangle className="h-4 w-4 text-destructive" />Escalated ({escalated.length})</div>
            <ul className="max-h-72 divide-y overflow-y-auto text-sm">
              {escalated.map((t) => (
                <li key={t.id} className="px-4 py-2">
                  <Link to="/tasks/$id" params={{ id: t.id }} className="font-medium hover:underline">{t.title}</Link>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground"><PriorityBadge priority={t.priority} />{names[t.assigned_to ?? ""]} · {daysOverdue(t)}d overdue</div>
                </li>
              ))}
              {escalated.length === 0 && <li className="px-4 py-6 text-center text-muted-foreground">Nothing escalated.</li>}
            </ul>
          </div>
          <div className="card-surface">
            <div className="border-b px-4 py-3 font-display text-lg font-bold uppercase">Reminders</div>
            <ul className="max-h-72 divide-y overflow-y-auto text-sm">
              {alerts.map(({ t, msg }) => (
                <li key={t.id + msg} className="flex items-center justify-between gap-2 px-4 py-2">
                  <Link to="/tasks/$id" params={{ id: t.id }} className="truncate hover:underline">{t.title}</Link>
                  <StatusBadge status={msg} />
                </li>
              ))}
              {docAlerts.map((d) => (
                <li key={d.v + d.doc} className="flex items-center justify-between gap-2 px-4 py-2">
                  <span className="truncate"><b>{d.v}</b> {d.doc} {d.expired ? "expired" : "expiring"} {fmtDate(d.date)}</span>
                  <StatusBadge status={d.expired ? "Expired" : "Vehicle doc"} />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
