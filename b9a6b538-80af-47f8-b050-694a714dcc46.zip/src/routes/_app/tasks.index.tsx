import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { TaskTable } from "@/components/task-table";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";
import { employeeMap, useEmployees, useTasks } from "@/lib/data";

export const Route = createFileRoute("/_app/tasks/")({
  head: () => ({ meta: [{ title: "All Tasks — MS Transport To-Do" }, { name: "description", content: "All company tasks with filters." }, { property: "og:title", content: "All Tasks" }, { property: "og:description", content: "All company tasks." }] }),
  component: AllTasks,
});

function AllTasks() {
  const { isOwner } = useSession();
  const { data: tasks = [] } = useTasks();
  const { data: emps = [] } = useEmployees();
  if (!isOwner) return <OwnerOnly />;
  return (
    <>
      <PageHeader title="All Tasks" subtitle="Pending work stays here until completed or cancelled with a reason.">
        <Button asChild className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/tasks/new"><Plus className="mr-1 h-4 w-4" />Add new task</Link></Button>
      </PageHeader>
      <TaskTable tasks={tasks} names={employeeMap(emps)} />
    </>
  );
}
