import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { UserPlus } from "lucide-react";
import { OwnerOnly, PageHeader } from "@/components/page";
import { Pill } from "@/components/badges";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { useEmployees, useInvalidate } from "@/lib/data";
import { createStaffLogin, resetStaffPassword, setStaffActive } from "@/lib/staff.functions";
import type { Employee } from "@/lib/task-utils";

export const Route = createFileRoute("/_app/employees/")({
  head: () => ({ meta: [{ title: "Employees — MS Transport To-Do" }, { name: "description", content: "Manage managers and staff logins." }, { property: "og:title", content: "Employees" }, { property: "og:description", content: "Manage staff." }] }),
  component: Employees,
});

function Employees() {
  const { isOwner } = useSession();
  const { data: emps = [] } = useEmployees();
  const invalidate = useInvalidate();
  const createLogin = useServerFn(createStaffLogin);
  const resetPw = useServerFn(resetStaffPassword);
  const setActive = useServerFn(setStaffActive);
  const [adding, setAdding] = useState(false);
  const [loginFor, setLoginFor] = useState<Employee | null>(null);
  const [resetFor, setResetFor] = useState<Employee | null>(null);
  const [f, setF] = useState({ name: "", designation: "", department: "", mobile: "" });
  const [cred, setCred] = useState({ email: "", password: "" });
  if (!isOwner) return <OwnerOnly />;

  const run = async (fn: () => Promise<unknown>, ok: string) => {
    try { await fn(); toast.success(ok); await invalidate("employees"); } catch (e) { toast.error((e as Error).message); }
  };

  return (
    <>
      <PageHeader title="Employees" subtitle="Create staff, give them a login, reset passwords or disable access.">
        <Button onClick={() => setAdding(true)} className="bg-accent text-accent-foreground hover:bg-accent/90"><UserPlus className="mr-1 h-4 w-4" />Add employee</Button>
      </PageHeader>
      <div className="card-surface overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
            <tr><th className="px-4 py-2">Name</th><th className="px-3 py-2">Designation</th><th className="px-3 py-2">Department</th><th className="px-3 py-2">Mobile</th><th className="px-3 py-2">Login</th><th className="px-3 py-2">Status</th><th className="px-3 py-2" /></tr>
          </thead>
          <tbody>
            {emps.map((e) => (
              <tr key={e.id} className="border-t">
                <td className="px-4 py-2 font-semibold"><Link to="/employees/$id" params={{ id: e.id }} className="text-primary hover:underline">{e.name}</Link></td>
                <td className="px-3 py-2">{e.designation}</td><td className="px-3 py-2">{e.department}</td><td className="px-3 py-2">{e.mobile ?? "—"}</td>
                <td className="px-3 py-2">{e.user_id ? <span className="text-xs">{e.email}</span> : <Pill tone="warning">No login</Pill>}</td>
                <td className="px-3 py-2">{e.is_owner ? <Pill tone="accent">Owner</Pill> : e.active ? <Pill tone="success">Active</Pill> : <Pill tone="neutral">Disabled</Pill>}</td>
                <td className="px-3 py-2 text-right whitespace-nowrap">
                  {!e.is_owner && (
                    <div className="flex justify-end gap-1">
                      {!e.user_id ? <Button size="sm" variant="outline" onClick={() => { setCred({ email: "", password: "" }); setLoginFor(e); }}>Create login</Button>
                        : <Button size="sm" variant="outline" onClick={() => { setCred({ email: "", password: "" }); setResetFor(e); }}>Reset password</Button>}
                      <Button size="sm" variant="ghost" onClick={() => run(() => setActive({ data: { employeeId: e.id, active: !e.active } }), e.active ? "Disabled" : "Enabled")}>{e.active ? "Disable" : "Enable"}</Button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={adding} onOpenChange={setAdding}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add employee</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {(["name", "designation", "department", "mobile"] as const).map((k) => (
              <Input key={k} placeholder={k.charAt(0).toUpperCase() + k.slice(1)} value={f[k]} maxLength={100} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
            ))}
            <Button className="w-full" onClick={() => run(async () => {
              if (!f.name.trim()) throw new Error("Name is required");
              const { error } = await supabase.from("employees").insert({ ...f, name: f.name.trim(), mobile: f.mobile || null });
              if (error) throw new Error(error.message);
              setAdding(false); setF({ name: "", designation: "", department: "", mobile: "" });
            }, "Employee added")}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!loginFor} onOpenChange={(o) => !o && setLoginFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create login for {loginFor?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input type="email" placeholder="Email (used as username)" value={cred.email} onChange={(e) => setCred({ ...cred, email: e.target.value })} />
            <Input type="text" placeholder="Temporary password (min 8 characters)" value={cred.password} onChange={(e) => setCred({ ...cred, password: e.target.value })} />
            <Button className="w-full" onClick={() => run(async () => { await createLogin({ data: { employeeId: loginFor!.id, ...cred } }); setLoginFor(null); }, "Login created")}>Create login</Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resetFor} onOpenChange={(o) => !o && setResetFor(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reset password — {resetFor?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input type="text" placeholder="New password (min 8 characters)" value={cred.password} onChange={(e) => setCred({ ...cred, password: e.target.value })} />
            <Button className="w-full" onClick={() => run(async () => { await resetPw({ data: { employeeId: resetFor!.id, password: cred.password } }); setResetFor(null); }, "Password reset")}>Reset</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
