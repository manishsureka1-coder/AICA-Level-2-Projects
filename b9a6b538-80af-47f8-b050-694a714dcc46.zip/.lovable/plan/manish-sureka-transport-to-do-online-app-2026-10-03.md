# Manish Sureka Transport To-Do — Online App

An online version of your brief, with real logins and a cloud database (Lovable Cloud). Built in phases so each stage works before the next starts.

## Phase 1 — Core (first build)
- Login for Owner (Manish Sureka) and staff; owner creates/disables staff and resets passwords. Roles kept in a separate secure table.
- Sidebar layout: Dashboard, My Tasks, All Tasks, Add Task, Employees, Vehicles, Customers, Daily Summary, Reports, AI Assistant, Completed Tasks, Audit Trail, Settings, Logout.
- Owner dashboard: 10 summary cards + clickable employee table (Open / Overdue / Completed Today / Critical).
- Employee dashboard with filters (today, pending, overdue, completed, date, customer, vehicle, category, priority, status).
- Add/Edit task with auto ID (MST-2026-00001), all categories, priorities, statuses, transport fields (vehicle, driver, customer, loading/unloading point, reference no.).
- Daily comments (never overwritten; date, time, user, status at the time).
- Carry forward: one task stays open, shows "Assigned on", "Pending for N days", overdue highlighting. Cancel requires a reason.
- Completed tasks: completion date/time/by, kept forever and searchable.
- Automatic audit trail of every change (assignment, due date, status, priority), read-only for staff.
- Global search across vehicle, customer, driver, LR, invoice, PO, tender, task ID, description, comments.
- Sample data: 10 staff, ~30 realistic tasks, vehicles, customers.

## Phase 2
- My To-Do — Manish Sureka (Today / Tomorrow / This Week / Overdue / Completed).
- Today's Management Summary with "Attention Required".
- Reminders and alerts: due today/tomorrow, overdue, critical pending, no update for 2 days, vehicle document expiring.
- Escalation: normal tasks overdue more than 2 days marked ESCALATED; overdue critical tasks shown at the top of the dashboard.
- Recurring tasks (daily, weekly, monthly, custom).

## Phase 3
- Reports (all 12 from the brief) with Excel and PDF export; full Excel workbook export (Tasks, Completed, Employees, Comments, Vehicles, Customers, Audit).
- Employee performance analytics with charts.
- AI Management Assistant: built-in rule-based observations (works with no paid AI), plus optional AI-written summary using built-in Lovable AI (no API key needed from you).

## Not applicable online
- Windows BAT files, Python virtual environment, SQLite file backup/restore: the cloud database is backed up automatically. A "download everything to Excel" button covers your data-export need.

## Design
Clean logistics dashboard: deep navy sidebar, amber accent (road/tanker feel), crisp tables, colour-coded status and priority badges, professional typography (not default fonts).

## Technical details
- TanStack Start + Lovable Cloud (Postgres, auth, RLS). Tables: profiles, user_roles, tasks, task_comments, task_history, task_recurrence, customers, vehicles, drivers, notifications, settings, audit_log, owner_todos.
- Audit and history written by database triggers so they cannot be bypassed; RLS: staff see own tasks, owner sees all.
- Staff accounts created by owner via server function using admin client after role check.
