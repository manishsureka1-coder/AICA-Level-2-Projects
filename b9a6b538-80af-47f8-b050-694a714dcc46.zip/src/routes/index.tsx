import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Truck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Sign in — Manish Sureka Transport To-Do" },
      { name: "description", content: "Assign, monitor and follow up daily transport tasks for managers and staff." },
      { property: "og:title", content: "Manish Sureka Transport To-Do" },
      { property: "og:description", content: "Task management and follow-up system for a transport company." },
    ],
  }),
  component: Login,
});

function Login() {
  const { session, loading, refresh } = useSession();
  const navigate = useNavigate();
  const [ownerExists, setOwnerExists] = useState<boolean | null>(null);
  const [mode, setMode] = useState<"signin" | "setup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("Manish Sureka");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.rpc("owner_exists").then(({ data }) => setOwnerExists(!!data));
  }, []);

  useEffect(() => {
    if (loading || !session) return;
    (async () => {
      const { data: exists } = await supabase.rpc("owner_exists");
      if (!exists) {
        await supabase.rpc("claim_owner", { _name: (session.user.user_metadata?.["name"] as string) ?? "Manish Sureka", _email: session.user.email ?? "" });
        await refresh();
      }
      navigate({ to: "/dashboard", replace: true });
    })();
  }, [loading, session]); // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    if (mode === "signin") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({
        email, password, options: { emailRedirectTo: window.location.origin, data: { name } },
      });
      if (error) toast.error(error.message);
      else if (!data.session) toast.success("Check your email and click the confirmation link, then sign in.");
    }
    setBusy(false);
  };

  return (
    <div className="grid min-h-screen md:grid-cols-2">
      <div className="hidden flex-col justify-between bg-sidebar p-12 text-sidebar-foreground md:flex">
        <div className="flex items-center gap-3 text-sidebar-primary"><Truck className="h-8 w-8" /><span className="text-xs font-semibold uppercase tracking-[0.3em]">Transport Management</span></div>
        <div>
          <h1 className="font-display text-6xl font-bold uppercase leading-[0.95] text-sidebar-accent-foreground">Nothing should<br />be <span className="text-sidebar-primary">forgotten.</span></h1>
          <p className="mt-6 max-w-md text-sm opacity-80">Who has to do what, by when, what is pending, why it is pending — and what requires my attention.</p>
        </div>
        <div className="text-xs opacity-60">Manish Sureka Transport To-Do · Capstone project</div>
      </div>
      <div className="flex items-center justify-center p-8">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4">
          <div>
            <h2 className="text-3xl font-bold uppercase">{mode === "signin" ? "Sign in" : "Set up owner account"}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {mode === "signin" ? "Managers and staff use the login given by the owner." : "This is a one-time setup for the owner, Manish Sureka."}
            </p>
          </div>
          {mode === "setup" && (
            <div className="space-y-1.5"><Label>Full name</Label><Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={100} /></div>
          )}
          <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
          <div className="space-y-1.5"><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} /></div>
          <Button type="submit" className="w-full" disabled={busy}>{mode === "signin" ? "Sign in" : "Create owner account"}</Button>
          {ownerExists === false && (
            <button type="button" className="w-full text-center text-sm text-muted-foreground underline" onClick={() => setMode(mode === "signin" ? "setup" : "signin")}>
              {mode === "signin" ? "First time? Set up the owner account" : "Back to sign in"}
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
